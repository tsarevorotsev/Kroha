package com.kroha.feeding.models;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TimeUtils {

    private static final SimpleDateFormat TIME_FMT =
        new SimpleDateFormat("HH:mm", Locale.getDefault());

    public static String formatClock(long ms) {
        return TIME_FMT.format(new Date(ms));
    }

    /** "1 ч 05 мин" или "12 мин" или "<1 мин" */
    public static String formatDuration(int totalSec) {
        int totalMin = Math.round(totalSec / 60f);
        if (totalMin < 1) return "<1 мин";
        int h = totalMin / 60;
        int m = totalMin % 60;
        if (h == 0) return m + " мин";
        return h + " ч " + String.format(Locale.getDefault(), "%02d", m) + " мин";
    }

    /** "12 мин" или "2 ч 30 мин" из миллисекунд */
    public static String formatGap(long ms) {
        int totalMin = (int)(ms / 60000);
        if (totalMin < 1) return "<1 мин";
        int h = totalMin / 60;
        int m = totalMin % 60;
        if (h == 0) return m + " мин";
        return h + " ч " + String.format(Locale.getDefault(), "%02d", m) + " мин";
    }

    /** "05:23" секундомер */
    public static String formatStopwatch(int totalSec) {
        int s = Math.max(0, totalSec);
        int h = s / 3600;
        int m = (s % 3600) / 60;
        int ss = s % 60;
        if (h > 0)
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, ss);
        return String.format(Locale.getDefault(), "%02d:%02d", m, ss);
    }

    public static long startOfDay(long ts) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static final String[] MONTHS = {
        "января","февраля","марта","апреля","мая","июня",
        "июля","августа","сентября","октября","ноября","декабря"
    };

    public static String dayLabel(long ts) {
        long today = startOfDay(System.currentTimeMillis());
        long day = startOfDay(ts);
        if (day == today) return "Сегодня";
        if (day == today - 86400000L) return "Вчера";
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ts);
        return c.get(Calendar.DAY_OF_MONTH) + " " + MONTHS[c.get(Calendar.MONTH)];
    }

    public static String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h < 5) return "Доброй ночи";
        if (h < 12) return "Доброе утро";
        if (h < 18) return "Добрый день";
        return "Добрый вечер";
    }
}
