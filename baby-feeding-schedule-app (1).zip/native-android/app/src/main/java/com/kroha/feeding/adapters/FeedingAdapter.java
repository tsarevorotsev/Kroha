package com.kroha.feeding.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.kroha.feeding.R;
import com.kroha.feeding.models.Feeding;
import com.kroha.feeding.models.TimeUtils;
import java.util.List;

public class FeedingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM   = 1;

    public interface OnDeleteListener { void onDelete(String id); }
    public interface OnEditListener   { void onEdit(String id);   }

    private final List<Object> items;
    private final OnDeleteListener deleteListener;
    private final OnEditListener   editListener;

    public FeedingAdapter(List<Object> items,
                          OnDeleteListener deleteListener,
                          OnEditListener   editListener) {
        this.items          = items;
        this.deleteListener = deleteListener;
        this.editListener   = editListener;
    }

    @Override public int getItemViewType(int pos) {
        return items.get(pos) instanceof String ? TYPE_HEADER : TYPE_ITEM;
    }

    @Override public int getItemCount() { return items.size(); }

    @NonNull @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (type == TYPE_HEADER)
            return new HeaderVH(inf.inflate(R.layout.item_day_header, parent, false));
        return new FeedingVH(inf.inflate(R.layout.item_feeding, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int pos) {
        if (h instanceof HeaderVH) {
            ((HeaderVH) h).tv.setText((String) items.get(pos));
            return;
        }

        Feeding f = (Feeding) items.get(pos);
        FeedingVH fh = (FeedingVH) h;

        fh.tvKind.setText(f.getKindEmoji() + " " + f.getKindLabel());
        fh.tvTime.setText(TimeUtils.formatClock(f.startedAt));
        fh.tvDetails.setText(f.getDetails());

        int bg;
        switch (f.kind) {
            case "bottle": bg = R.drawable.kind_bottle_bg; break;
            case "solid":  bg = R.drawable.kind_solid_bg;  break;
            default:       bg = R.drawable.kind_breast_bg; break;
        }
        fh.iconBg.setBackgroundResource(bg);

        fh.btnEdit.setOnClickListener(v -> editListener.onEdit(f.id));
        fh.btnDelete.setOnClickListener(v -> deleteListener.onDelete(f.id));
    }

    /* ----------------------- ViewHolders ----------------------- */

    static class HeaderVH extends RecyclerView.ViewHolder {
        TextView tv;
        HeaderVH(View v) { super(v); tv = v.findViewById(R.id.tv_day); }
    }

    static class FeedingVH extends RecyclerView.ViewHolder {
        View iconBg;
        TextView tvKind, tvTime, tvDetails;
        ImageButton btnEdit, btnDelete;

        FeedingVH(View v) {
            super(v);
            iconBg    = v.findViewById(R.id.icon_bg);
            tvKind    = v.findViewById(R.id.tv_kind);
            tvTime    = v.findViewById(R.id.tv_time);
            tvDetails = v.findViewById(R.id.tv_details);
            btnEdit   = v.findViewById(R.id.btn_edit);
            btnDelete = v.findViewById(R.id.btn_delete);
        }
    }
}
