package com.kroha.feeding.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.kroha.feeding.NotifyHelper;
import com.kroha.feeding.models.FeedingStore;
import com.kroha.feeding.models.TimeUtils;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        FeedingStore store = FeedingStore.get(ctx);
        String name = store.getBabyName();

        Long dueAt = store.nextFeedingAt();
        long now = System.currentTimeMillis();

        if (dueAt != null && now >= dueAt) {
            long overdue = now - dueAt;
            if (overdue < 60000) {
                NotifyHelper.showNotification(ctx,
                    "🍼 Время кормить!",
                    "Прошло " + TimeUtils.formatGap(store.getIntervalMs()) +
                    " с последнего кормления " + name);
            } else {
                NotifyHelper.showNotification(ctx,
                    "🍼 Кормление опаздывает!",
                    "Уже " + TimeUtils.formatGap(overdue) +
                    " сверх интервала — пора кормить " + name);
            }
        } else {
            NotifyHelper.showNotification(ctx,
                "🍼 Скоро кормление",
                "Через " + store.getRemindMin() + " мин пора кормить " + name);
        }

        // Планируем повтор через 10 минут, если не покормили
        NotifyHelper.scheduleAlarm(ctx);
    }
}
