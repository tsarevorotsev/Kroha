package com.kroha.feeding.models;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class FeedingStore {

    private static final String PREFS = "kroha_prefs";
    private static final String KEY_FEEDINGS = "feedings_json";
    private static final String KEY_INTERVAL = "interval_min";
    private static final String KEY_REMIND = "remind_min";
    private static final String KEY_NOTIFY = "notifications_on";
    private static final String KEY_VIBRATE = "vibrate_on";
    private static final String KEY_SOUND = "sound_on";
    private static final String KEY_BABY_NAME = "baby_name";

    private static FeedingStore instance;
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private List<Feeding> feedings;

    private FeedingStore(Context ctx) {
        prefs = ctx.getApplicationContext()
                   .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        load();
    }

    public static synchronized FeedingStore get(Context ctx) {
        if (instance == null) instance = new FeedingStore(ctx);
        return instance;
    }

    /* ======================== Feedings ======================== */

    private void load() {
        String json = prefs.getString(KEY_FEEDINGS, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<Feeding>>(){}.getType();
            feedings = gson.fromJson(json, type);
            if (feedings == null) feedings = new ArrayList<>();
        } else {
            feedings = new ArrayList<>();
        }
        // Исправляем null-note для старых записей
        for (Feeding f : feedings) {
            if (f.note == null) f.note = "";
        }
        sort();
    }

    private void save() {
        prefs.edit().putString(KEY_FEEDINGS, gson.toJson(feedings)).apply();
    }

    private void sort() {
        Collections.sort(feedings, new Comparator<Feeding>() {
            @Override public int compare(Feeding a, Feeding b) {
                return Long.compare(b.startedAt, a.startedAt);
            }
        });
    }

    public List<Feeding> getAll() { return feedings; }

    public Feeding getLast() {
        return feedings.isEmpty() ? null : feedings.get(0);
    }

    /** Найти запись по id */
    public Feeding getById(String id) {
        for (Feeding f : feedings) {
            if (f.id.equals(id)) return f;
        }
        return null;
    }

    public void add(Feeding f) {
        feedings.add(0, f);
        sort();
        save();
    }

    /** Обновить существующую запись (по id) */
    public void update(Feeding updated) {
        for (int i = 0; i < feedings.size(); i++) {
            if (feedings.get(i).id.equals(updated.id)) {
                feedings.set(i, updated);
                sort();
                save();
                return;
            }
        }
    }

    public void remove(String id) {
        for (int i = 0; i < feedings.size(); i++) {
            if (feedings.get(i).id.equals(id)) {
                feedings.remove(i);
                break;
            }
        }
        save();
    }

    public void clearAll() {
        feedings.clear();
        save();
    }

    public List<Feeding> getToday() {
        long today = TimeUtils.startOfDay(System.currentTimeMillis());
        List<Feeding> result = new ArrayList<>();
        for (Feeding f : feedings) {
            if (f.startedAt >= today) result.add(f);
        }
        return result;
    }

    /** Время, когда наступит следующее кормление (или null) */
    public Long nextFeedingAt() {
        Feeding last = getLast();
        if (last == null) return null;
        return last.endTime() + getIntervalMs();
    }

    /* ======================== Settings ======================== */

    public int getIntervalMin() { return prefs.getInt(KEY_INTERVAL, 180); }
    public void setIntervalMin(int v) { prefs.edit().putInt(KEY_INTERVAL, v).apply(); }
    public long getIntervalMs() { return getIntervalMin() * 60000L; }

    public int getRemindMin() { return prefs.getInt(KEY_REMIND, 10); }
    public void setRemindMin(int v) { prefs.edit().putInt(KEY_REMIND, v).apply(); }

    public boolean isNotifyOn() { return prefs.getBoolean(KEY_NOTIFY, true); }
    public void setNotifyOn(boolean v) { prefs.edit().putBoolean(KEY_NOTIFY, v).apply(); }

    public boolean isVibrateOn() { return prefs.getBoolean(KEY_VIBRATE, true); }
    public void setVibrateOn(boolean v) { prefs.edit().putBoolean(KEY_VIBRATE, v).apply(); }

    public boolean isSoundOn() { return prefs.getBoolean(KEY_SOUND, true); }
    public void setSoundOn(boolean v) { prefs.edit().putBoolean(KEY_SOUND, v).apply(); }

    public String getBabyName() { return prefs.getString(KEY_BABY_NAME, "Малыш"); }
    public void setBabyName(String v) { prefs.edit().putString(KEY_BABY_NAME, v).apply(); }
}
