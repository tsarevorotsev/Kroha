package com.kroha.feeding.fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.kroha.feeding.NotifyHelper;
import com.kroha.feeding.R;
import com.kroha.feeding.adapters.FeedingAdapter;
import com.kroha.feeding.models.Feeding;
import com.kroha.feeding.models.FeedingStore;
import com.kroha.feeding.models.TimeUtils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HistoryFragment extends Fragment {

    private FeedingStore store;
    private RecyclerView recycler;
    private TextView tvEmpty;
    private FeedingAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup p, @Nullable Bundle s) {
        return inf.inflate(R.layout.fragment_history, p, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        store   = FeedingStore.get(requireContext());
        recycler = v.findViewById(R.id.recycler);
        tvEmpty  = v.findViewById(R.id.tv_empty);
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));

        v.findViewById(R.id.btn_add).setOnClickListener(b -> showEditDialog(null));

        loadData();
    }

    @Override public void onResume() { super.onResume(); loadData(); }

    /* ========================= список ========================= */

    private void loadData() {
        List<Feeding> all = store.getAll();
        if (all.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recycler.setVisibility(View.GONE);
            return;
        }
        tvEmpty.setVisibility(View.GONE);
        recycler.setVisibility(View.VISIBLE);

        // Группируем по дням
        Map<Long, List<Feeding>> grouped = new LinkedHashMap<>();
        for (Feeding f : all) {
            long day = TimeUtils.startOfDay(f.startedAt);
            List<Feeding> list = grouped.get(day);
            if (list == null) { list = new ArrayList<>(); grouped.put(day, list); }
            list.add(f);
        }

        List<Object> items = new ArrayList<>();
        for (Map.Entry<Long, List<Feeding>> e : grouped.entrySet()) {
            items.add(TimeUtils.dayLabel(e.getKey()));
            items.addAll(e.getValue());
        }

        adapter = new FeedingAdapter(
            items,
            id -> confirmDelete(id),          // удаление
            id -> showEditDialog(id)           // редактирование
        );
        recycler.setAdapter(adapter);
    }

    private void confirmDelete(String id) {
        Feeding f = store.getById(id);
        if (f == null) return;
        new AlertDialog.Builder(requireContext())
            .setTitle("Удалить запись?")
            .setMessage(f.getKindLabel() + " в " + TimeUtils.formatClock(f.startedAt))
            .setPositiveButton("Удалить", (d, w) -> { store.remove(id); loadData(); })
            .setNegativeButton("Отмена", null)
            .show();
    }

    /* =================== диалог добавить / редактировать =================== */

    /**
     * @param editId  null → новая запись, иначе — id для редактирования
     */
    private void showEditDialog(@Nullable String editId) {
        boolean isEdit = (editId != null);
        Feeding existing = isEdit ? store.getById(editId) : null;

        View dv = LayoutInflater.from(requireContext())
                    .inflate(R.layout.dialog_edit_feeding, null);

        // Состояние
        final String[]  kind      = { existing != null ? existing.kind : "breast" };
        final Calendar  cal       = Calendar.getInstance();
        if (existing != null) cal.setTimeInMillis(existing.startedAt);
        final int[]     durMin    = { existing != null ? existing.durationSec / 60 : 15 };
        final int[]     leftMin   = { existing != null ? existing.leftSec  / 60 : 0 };
        final int[]     rightMin  = { existing != null ? existing.rightSec / 60 : 0 };
        final int[]     ml        = { existing != null && "bottle".equals(existing.kind) ? existing.amount : 120 };
        final int[]     grams     = { existing != null && "solid".equals(existing.kind)  ? existing.amount : 80  };

        // Виджеты
        TextView tvTitle       = dv.findViewById(R.id.tv_dialog_title);
        LinearLayout blockKind = dv.findViewById(R.id.block_kind);
        RadioGroup rgKind      = dv.findViewById(R.id.rg_kind);
        RadioButton rbBreast   = dv.findViewById(R.id.rb_breast);
        RadioButton rbBottle   = dv.findViewById(R.id.rb_bottle);
        RadioButton rbSolid    = dv.findViewById(R.id.rb_solid);

        Button btnDate = dv.findViewById(R.id.btn_pick_date);
        Button btnTime = dv.findViewById(R.id.btn_pick_time);

        LinearLayout blockDur   = dv.findViewById(R.id.block_duration);
        TextView tvDur          = dv.findViewById(R.id.tv_duration);
        LinearLayout blockSides = dv.findViewById(R.id.block_sides);
        TextView tvLeft         = dv.findViewById(R.id.tv_left_dur);
        TextView tvRight        = dv.findViewById(R.id.tv_right_dur);
        LinearLayout blockMl    = dv.findViewById(R.id.block_ml);
        TextView tvMl           = dv.findViewById(R.id.tv_ml);
        LinearLayout blockGrams = dv.findViewById(R.id.block_grams);
        TextView tvGramsView    = dv.findViewById(R.id.tv_grams);

        EditText etNote = dv.findViewById(R.id.et_note);
        Button btnSave  = dv.findViewById(R.id.btn_save);

        // Заголовок
        tvTitle.setText(isEdit ? "Редактировать кормление" : "Добавить кормление");

        // При редактировании тип не меняем
        if (isEdit) {
            blockKind.setVisibility(View.GONE);
        } else {
            blockKind.setVisibility(View.VISIBLE);
            rbBreast.setChecked(true);
        }

        // Текущее значение заметки
        if (existing != null && existing.note != null)
            etNote.setText(existing.note);

        // ---- утилиты обновления отображения ----
        Runnable refreshDate = () -> {
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat(
                "dd MMM yyyy", new java.util.Locale("ru"));
            btnDate.setText(df.format(cal.getTime()));
        };
        Runnable refreshTime = () -> btnTime.setText(
            TimeUtils.formatClock(cal.getTimeInMillis()));
        Runnable refreshDur  = () -> tvDur.setText(
            TimeUtils.formatDuration(durMin[0] * 60));
        Runnable refreshLeft  = () -> tvLeft.setText(
            TimeUtils.formatDuration(leftMin[0] * 60));
        Runnable refreshRight = () -> tvRight.setText(
            TimeUtils.formatDuration(rightMin[0] * 60));
        Runnable refreshMl    = () -> tvMl.setText(ml[0] + " мл");
        Runnable refreshGrams = () -> tvGramsView.setText(grams[0] + " г");

        refreshDate.run(); refreshTime.run();
        refreshDur.run(); refreshLeft.run(); refreshRight.run();
        refreshMl.run(); refreshGrams.run();

        // ---- показ блоков по типу ----
        Runnable applyKind = () -> {
            boolean isBreast = "breast".equals(kind[0]);
            boolean isBottle = "bottle".equals(kind[0]);
            boolean isSolid  = "solid".equals(kind[0]);
            blockDur.setVisibility(isBreast || isBottle ? View.VISIBLE : View.GONE);
            blockSides.setVisibility(isBreast ? View.VISIBLE : View.GONE);
            blockMl.setVisibility(isBottle ? View.VISIBLE : View.GONE);
            blockGrams.setVisibility(isSolid ? View.VISIBLE : View.GONE);
        };
        applyKind.run();

        // ---- выбор типа ----
        rgKind.setOnCheckedChangeListener((g, id2) -> {
            if (id2 == R.id.rb_breast) kind[0] = "breast";
            else if (id2 == R.id.rb_bottle) kind[0] = "bottle";
            else kind[0] = "solid";
            applyKind.run();
        });

        // ---- выбор даты ----
        btnDate.setOnClickListener(b -> new DatePickerDialog(
            requireContext(),
            (dp, y, m, d2) -> {
                cal.set(y, m, d2);
                refreshDate.run();
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show());

        // ---- выбор времени ----
        btnTime.setOnClickListener(b -> new TimePickerDialog(
            requireContext(),
            (tp, h, min) -> {
                cal.set(Calendar.HOUR_OF_DAY, h);
                cal.set(Calendar.MINUTE, min);
                refreshTime.run();
            },
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            true
        ).show());

        // ---- длительность ----
        dv.findViewById(R.id.btn_dur_minus).setOnClickListener(b -> {
            if (durMin[0] > 1) { durMin[0]--; refreshDur.run(); }
        });
        dv.findViewById(R.id.btn_dur_plus).setOnClickListener(b -> {
            if (durMin[0] < 240) { durMin[0]++; refreshDur.run(); }
        });

        // ---- левая / правая ----
        dv.findViewById(R.id.btn_left_minus).setOnClickListener(b -> {
            if (leftMin[0] > 0) { leftMin[0]--; refreshLeft.run(); }
        });
        dv.findViewById(R.id.btn_left_plus).setOnClickListener(b -> {
            if (leftMin[0] < 120) { leftMin[0]++; refreshLeft.run(); }
        });
        dv.findViewById(R.id.btn_right_minus).setOnClickListener(b -> {
            if (rightMin[0] > 0) { rightMin[0]--; refreshRight.run(); }
        });
        dv.findViewById(R.id.btn_right_plus).setOnClickListener(b -> {
            if (rightMin[0] < 120) { rightMin[0]++; refreshRight.run(); }
        });

        // ---- мл ----
        dv.findViewById(R.id.btn_ml_minus).setOnClickListener(b -> {
            if (ml[0] >= 10) { ml[0] -= 10; refreshMl.run(); }
        });
        dv.findViewById(R.id.btn_ml_plus).setOnClickListener(b -> {
            if (ml[0] <= 390) { ml[0] += 10; refreshMl.run(); }
        });

        // ---- граммы ----
        dv.findViewById(R.id.btn_gr_minus).setOnClickListener(b -> {
            if (grams[0] >= 10) { grams[0] -= 10; refreshGrams.run(); }
        });
        dv.findViewById(R.id.btn_gr_plus).setOnClickListener(b -> {
            if (grams[0] <= 390) { grams[0] += 10; refreshGrams.run(); }
        });

        // ---- создаём диалог ----
        AlertDialog dialog = new AlertDialog.Builder(requireContext())
            .setView(dv)
            .create();
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // ---- сохранение ----
        btnSave.setOnClickListener(b -> {
            long startMs = cal.getTimeInMillis();
            int durSec   = "solid".equals(kind[0]) ? 0 : durMin[0] * 60;
            int lSec     = "breast".equals(kind[0]) ? leftMin[0]  * 60 : 0;
            int rSec     = "breast".equals(kind[0]) ? rightMin[0] * 60 : 0;
            int amount   = "bottle".equals(kind[0]) ? ml[0]
                         : "solid".equals(kind[0])  ? grams[0] : 0;
            String note  = etNote.getText().toString().trim();

            if (isEdit && existing != null) {
                existing.kind        = kind[0];
                existing.startedAt   = startMs;
                existing.durationSec = durSec;
                existing.leftSec     = lSec;
                existing.rightSec    = rSec;
                existing.amount      = amount;
                existing.note        = note;
                store.update(existing);
            } else {
                Feeding f = new Feeding(kind[0], startMs, durSec, lSec, rSec, amount);
                f.note = note;
                store.add(f);
            }

            NotifyHelper.scheduleAlarm(requireContext());
            dialog.dismiss();
            loadData();
        });

        dv.findViewById(R.id.btn_cancel_dialog).setOnClickListener(b -> dialog.dismiss());
        dialog.show();
    }
}
