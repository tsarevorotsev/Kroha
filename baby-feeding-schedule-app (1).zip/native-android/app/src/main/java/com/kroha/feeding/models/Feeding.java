package com.kroha.feeding.models;

public class Feeding {
    public String id;
    public String kind;     // "breast", "bottle", "solid"
    public long startedAt;  // timestamp ms
    public int durationSec;
    public int leftSec;
    public int rightSec;
    public int amount;      // мл для бутылочки, граммы для прикорма
    public String note;     // необязательная заметка

    public Feeding() {
        this.id = Long.toHexString(System.currentTimeMillis()) +
                  Integer.toHexString((int)(Math.random() * 0xFFFF));
        this.note = "";
    }

    public Feeding(String kind, long startedAt, int durationSec,
                   int leftSec, int rightSec, int amount) {
        this();
        this.kind = kind;
        this.startedAt = startedAt;
        this.durationSec = durationSec;
        this.leftSec = leftSec;
        this.rightSec = rightSec;
        this.amount = amount;
    }

    public long endTime() {
        return startedAt + Math.max(durationSec, 0) * 1000L;
    }

    public String getKindLabel() {
        switch (kind) {
            case "breast": return "Грудь";
            case "bottle": return "Бутылочка";
            case "solid":  return "Прикорм";
            default: return kind;
        }
    }

    public String getKindEmoji() {
        switch (kind) {
            case "breast": return "🤱";
            case "bottle": return "🍼";
            case "solid":  return "🥣";
            default: return "•";
        }
    }

    public String getDetails() {
        StringBuilder sb = new StringBuilder();
        switch (kind) {
            case "breast":
                sb.append(TimeUtils.formatDuration(durationSec));
                if (leftSec > 0 && rightSec > 0) {
                    sb.append(" · Л ").append(TimeUtils.formatDuration(leftSec))
                      .append(" · П ").append(TimeUtils.formatDuration(rightSec));
                } else if (leftSec > 0) {
                    sb.append(" · левая");
                } else if (rightSec > 0) {
                    sb.append(" · правая");
                }
                break;
            case "bottle":
                sb.append(amount).append(" мл");
                if (durationSec > 0)
                    sb.append(" · ").append(TimeUtils.formatDuration(durationSec));
                break;
            case "solid":
                sb.append(amount).append(" г");
                break;
        }
        if (note != null && !note.isEmpty()) {
            sb.append(" · ").append(note);
        }
        return sb.toString();
    }
}
