package com.kroha.feeding.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.kroha.feeding.NotifyHelper;

/**
 * После перезагрузки телефона переустанавливает будильник.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            NotifyHelper.scheduleAlarm(ctx);
        }
    }
}
