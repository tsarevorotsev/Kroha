package com.kroha.feeding.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.kroha.feeding.ActiveFeedingActivity;
import com.kroha.feeding.NotifyHelper;
import com.kroha.feeding.R;
import com.kroha.feeding.models.Feeding;
import com.kroha.feeding.models.FeedingStore;
import com.kroha.feeding.models.TimeUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private FeedingStore store;
    private Handler handler;
    private Runnable ticker;

    private TextView tvGreeting, tvDate, tvTimerLabel, tvTimer, tvTimerSub;
    private TextView tvLastInfo, tvNextTime, tvTodayCount, tvTodayBreast, tvTodayMl, tvTip;
    private LinearLayout layoutLast, cardNext;

    private static final String[] TIPS = {
        "Держите малыша вертикально «столбиком» 5–10 минут после кормления.",
        "При грудном вскармливании чередуйте сторону — начинайте с той, что была второй.",
        "Ориентируйтесь на признаки голода: причмокивание, поиск груди, кулачки в рот.",
        "Тёплый душ и спокойная обстановка помогают кормить без спешки.",
        "Смесь храните не дольше 2 часов при комнатной температуре.",
        "Прикорм лучше давать до молока — малыш охотнее пробует новое.",
        "Записывайте каждое кормление — ритм помогает замечать изменения.",
        "Ночью кормите в приглушённом свете, чтобы не сбивать режим сна."
    };

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup p, @Nullable Bundle s) {
        return inf.inflate(R.layout.fragment_home, p, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        store   = FeedingStore.get(requireContext());
        handler = new Handler(Looper.getMainLooper());

        tvGreeting    = v.findViewById(R.id.tv_greeting);
        tvDate        = v.findViewById(R.id.tv_date);
        tvTimerLabel  = v.findViewById(R.id.tv_timer_label);
        tvTimer       = v.findViewById(R.id.tv_timer);
        tvTimerSub    = v.findViewById(R.id.tv_timer_sub);
        tvLastInfo    = v.findViewById(R.id.tv_last_info);
        layoutLast    = v.findViewById(R.id.layout_last);
        cardNext      = v.findViewById(R.id.card_next);
        tvNextTime    = v.findViewById(R.id.tv_next_time);
        tvTodayCount  = v.findViewById(R.id.tv_today_count);
        tvTodayBreast = v.findViewById(R.id.tv_today_breast);
        tvTodayMl     = v.findViewById(R.id.tv_today_ml);
        tvTip         = v.findViewById(R.id.tv_tip);

        v.findViewById(R.id.btn_start).setOnClickListener(b -> showPickSheet());

        int tipIdx = (int)((System.currentTimeMillis() / 86400000) % TIPS.length);
        tvTip.setText(TIPS[tipIdx]);

        tvGreeting.setText(TimeUtils.greeting() + "!");
        SimpleDateFormat df = new SimpleDateFormat("EEEE, d MMMM", new Locale("ru"));
        tvDate.setText(df.format(new Date()));

        ticker = new Runnable() {
            @Override public void run() { updateUI(); handler.postDelayed(this, 1000); }
        };
    }

    @Override public void onResume() { super.onResume(); handler.post(ticker); }
    @Override public void onPause()  { super.onPause();  handler.removeCallbacks(ticker); }

    /* ========================= UI-обновление ========================= */

    private void updateUI() {
        Feeding last = store.getLast();
        long now = System.currentTimeMillis();

        if (last != null) {
            long end      = last.endTime();
            long interval = store.getIntervalMs();
            long dueAt    = end + interval;
            long remaining = dueAt - now;

            if (remaining <= 0) {
                tvTimerLabel.setText("ПОРА КОРМИТЬ");
                tvTimerLabel.setTextColor(0xFFF25C40);
                tvTimer.setText("+" + TimeUtils.formatGap(-remaining));
                tvTimer.setTextColor(0xFFF25C40);
                tvTimerSub.setText("сверх интервала " + TimeUtils.formatGap(interval));
            } else {
                tvTimerLabel.setText("ДО КОРМЛЕНИЯ");
                tvTimerLabel.setTextColor(0xFF8A6F7B);
                tvTimer.setText(TimeUtils.formatStopwatch((int)(remaining / 1000)));
                tvTimer.setTextColor(0xFF40303B);
                tvTimerSub.setText("прошло " + TimeUtils.formatGap(now - end) +
                                   " из " + TimeUtils.formatGap(interval));
            }

            layoutLast.setVisibility(View.VISIBLE);
            String info = last.getKindEmoji() + " Последнее: " +
                TimeUtils.formatClock(last.startedAt) + " · ";
            if      ("breast".equals(last.kind)) info += TimeUtils.formatDuration(last.durationSec) + " у груди";
            else if ("bottle".equals(last.kind)) info += last.amount + " мл";
            else                                  info += last.amount + " г прикорма";
            tvLastInfo.setText(info);

            cardNext.setVisibility(View.VISIBLE);
            tvNextTime.setText(remaining <= 0 ? "Прямо сейчас!" :
                "в " + TimeUtils.formatClock(dueAt) + " — через " + TimeUtils.formatGap(remaining));

        } else {
            tvTimerLabel.setText("НАЧНИТЕ ПЕРВОЕ КОРМЛЕНИЕ");
            tvTimerLabel.setTextColor(0xFF8A6F7B);
            tvTimer.setText("--:--");
            tvTimer.setTextColor(0xFF40303B);
            tvTimerSub.setText("");
            layoutLast.setVisibility(View.GONE);
            cardNext.setVisibility(View.GONE);
        }

        // Сегодняшняя статистика
        List<Feeding> today = store.getToday();
        tvTodayCount.setText(String.valueOf(today.size()));

        int breastSec = 0, totalMl = 0;
        for (Feeding f : today) {
            if ("breast".equals(f.kind)) breastSec += f.durationSec;
            if ("bottle".equals(f.kind)) totalMl   += f.amount;
        }
        tvTodayBreast.setText(breastSec > 0 ? TimeUtils.formatDuration(breastSec) : "—");
        tvTodayMl.setText(totalMl > 0 ? totalMl + " мл" : "—");
    }

    /* ========================= BottomSheet выбора типа ========================= */

    /**
     * Используем BottomSheetDialog — он сам выезжает поверх навигации
     * и никогда не скрывается за нижним баром.
     */
    private void showPickSheet() {
        BottomSheetDialog sheet = new BottomSheetDialog(requireContext());
        View sv = LayoutInflater.from(requireContext())
                    .inflate(R.layout.dialog_pick_type, null);
        sheet.setContentView(sv);

        sv.findViewById(R.id.btn_breast).setOnClickListener(b -> {
            sheet.dismiss();
            startActivity(new Intent(requireContext(), ActiveFeedingActivity.class)
                .putExtra("kind", "breast"));
        });

        sv.findViewById(R.id.btn_bottle).setOnClickListener(b -> {
            sheet.dismiss();
            startActivity(new Intent(requireContext(), ActiveFeedingActivity.class)
                .putExtra("kind", "bottle"));
        });

        sv.findViewById(R.id.btn_solid).setOnClickListener(b -> {
            sheet.dismiss();
            showSolidSheet();
        });

        sheet.show();
    }

    /* ========================= BottomSheet прикорма ========================= */

    private void showSolidSheet() {
        final int[] grams = { 80 };

        BottomSheetDialog sheet = new BottomSheetDialog(requireContext());
        View dv = LayoutInflater.from(requireContext())
                    .inflate(R.layout.dialog_edit_feeding, null);
        sheet.setContentView(dv);

        // Настраиваем диалог под прикорм: скрываем лишнее
        dv.findViewById(R.id.block_kind).setVisibility(View.GONE);
        dv.findViewById(R.id.block_duration).setVisibility(View.GONE);
        dv.findViewById(R.id.block_sides).setVisibility(View.GONE);
        dv.findViewById(R.id.block_ml).setVisibility(View.GONE);
        dv.findViewById(R.id.block_grams).setVisibility(View.VISIBLE);
        ((TextView) dv.findViewById(R.id.tv_dialog_title)).setText("🥣 Добавить прикорм");

        // Инициализируем дату/время — сейчас
        java.util.Calendar cal = java.util.Calendar.getInstance();
        Button btnDate = dv.findViewById(R.id.btn_pick_date);
        Button btnTime = dv.findViewById(R.id.btn_pick_time);
        java.text.SimpleDateFormat dfDate = new java.text.SimpleDateFormat("dd MMM yyyy", new Locale("ru"));
        btnDate.setText(dfDate.format(cal.getTime()));
        btnTime.setText(TimeUtils.formatClock(cal.getTimeInMillis()));

        btnDate.setOnClickListener(b -> new android.app.DatePickerDialog(requireContext(),
            (dp, y, m, d2) -> { cal.set(y, m, d2); btnDate.setText(dfDate.format(cal.getTime())); },
            cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH),
            cal.get(java.util.Calendar.DAY_OF_MONTH)).show());

        btnTime.setOnClickListener(b -> new android.app.TimePickerDialog(requireContext(),
            (tp, h, min) -> {
                cal.set(java.util.Calendar.HOUR_OF_DAY, h);
                cal.set(java.util.Calendar.MINUTE, min);
                btnTime.setText(TimeUtils.formatClock(cal.getTimeInMillis()));
            }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), true).show());

        // Граммы
        TextView tvGrams = dv.findViewById(R.id.tv_grams);
        tvGrams.setText(grams[0] + " г");
        dv.findViewById(R.id.btn_gr_minus).setOnClickListener(b -> {
            if (grams[0] >= 10) { grams[0] -= 10; tvGrams.setText(grams[0] + " г"); }
        });
        dv.findViewById(R.id.btn_gr_plus).setOnClickListener(b -> {
            if (grams[0] <= 390) { grams[0] += 10; tvGrams.setText(grams[0] + " г"); }
        });

        dv.findViewById(R.id.btn_save).setOnClickListener(b -> {
            Feeding f = new Feeding("solid", cal.getTimeInMillis(), 0, 0, 0, grams[0]);
            f.note = ((android.widget.EditText) dv.findViewById(R.id.et_note))
                        .getText().toString().trim();
            store.add(f);
            NotifyHelper.scheduleAlarm(requireContext());
            updateUI();
            sheet.dismiss();
        });

        dv.findViewById(R.id.btn_cancel_dialog).setOnClickListener(b -> sheet.dismiss());
        sheet.show();
    }
}
