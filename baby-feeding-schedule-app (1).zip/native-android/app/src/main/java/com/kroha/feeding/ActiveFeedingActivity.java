package com.kroha.feeding;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.kroha.feeding.models.Feeding;
import com.kroha.feeding.models.FeedingStore;
import com.kroha.feeding.models.TimeUtils;

public class ActiveFeedingActivity extends AppCompatActivity {

    private String kind;
    private long startedAt;
    private String currentSide = "left";
    private long sideSwitchedAt;
    private int leftSec = 0, rightSec = 0;
    private int amountMl = 120;

    private Handler handler;
    private Runnable ticker;
    private FeedingStore store;

    private TextView tvStopwatch, tvModeLabel;
    private TextView tvLeftTime, tvRightTime, tvMl;
    private Button btnLeft, btnRight;
    private LinearLayout layoutSides, layoutVolume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_feeding);

        store = FeedingStore.get(this);
        kind = getIntent().getStringExtra("kind");
        if (kind == null) kind = "breast";
        startedAt = System.currentTimeMillis();
        sideSwitchedAt = startedAt;

        handler = new Handler(Looper.getMainLooper());

        tvModeLabel  = findViewById(R.id.tv_mode_label);
        tvStopwatch  = findViewById(R.id.tv_stopwatch);
        layoutSides  = findViewById(R.id.layout_sides);
        layoutVolume = findViewById(R.id.layout_volume);
        btnLeft      = findViewById(R.id.btn_left);
        btnRight     = findViewById(R.id.btn_right);
        tvLeftTime   = findViewById(R.id.tv_left_time);
        tvRightTime  = findViewById(R.id.tv_right_time);
        tvMl         = findViewById(R.id.tv_ml);

        if ("breast".equals(kind)) {
            tvModeLabel.setText("🤱 Кормление грудью");
            layoutSides.setVisibility(View.VISIBLE);
            layoutVolume.setVisibility(View.GONE);
            updateSideButtons();
        } else {
            tvModeLabel.setText("🍼 Кормление из бутылочки");
            layoutSides.setVisibility(View.GONE);
            layoutVolume.setVisibility(View.VISIBLE);
            tvMl.setText(String.valueOf(amountMl));
        }

        // Side buttons
        btnLeft.setOnClickListener(v -> switchTo("left"));
        btnRight.setOnClickListener(v -> switchTo("right"));
        findViewById(R.id.btn_switch).setOnClickListener(v ->
            switchTo("left".equals(currentSide) ? "right" : "left"));

        // Volume buttons
        findViewById(R.id.btn_minus).setOnClickListener(v -> {
            amountMl = Math.max(0, amountMl - 10);
            tvMl.setText(String.valueOf(amountMl));
        });
        findViewById(R.id.btn_plus).setOnClickListener(v -> {
            amountMl = Math.min(400, amountMl + 10);
            tvMl.setText(String.valueOf(amountMl));
        });

        // Finish
        findViewById(R.id.btn_finish).setOnClickListener(v -> finishFeeding());

        // Cancel
        findViewById(R.id.btn_cancel).setOnClickListener(v -> finish());
        findViewById(R.id.btn_cancel_bottom).setOnClickListener(v -> finish());

        // Ticker
        ticker = new Runnable() {
            @Override public void run() {
                updateTimer();
                handler.postDelayed(this, 500);
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void switchTo(String side) {
        long now = System.currentTimeMillis();
        int add = (int)((now - sideSwitchedAt) / 1000);
        if ("left".equals(currentSide))  leftSec  += add;
        else                             rightSec += add;
        currentSide = side;
        sideSwitchedAt = now;
        updateSideButtons();
        vibrate();
    }

    private void updateSideButtons() {
        btnLeft.setBackgroundColor("left".equals(currentSide) ? 0xFFFFFFFF : 0x00000000);
        btnLeft.setTextColor("left".equals(currentSide) ? 0xFFF25C40 : 0xDDFFFFFF);
        btnRight.setBackgroundColor("right".equals(currentSide) ? 0xFFFFFFFF : 0x00000000);
        btnRight.setTextColor("right".equals(currentSide) ? 0xFFF25C40 : 0xDDFFFFFF);
    }

    private void updateTimer() {
        long now = System.currentTimeMillis();
        int total = (int)((now - startedAt) / 1000);
        tvStopwatch.setText(TimeUtils.formatStopwatch(total));

        if ("breast".equals(kind)) {
            int addNow = (int)((now - sideSwitchedAt) / 1000);
            int l = leftSec  + ("left".equals(currentSide) ? addNow : 0);
            int r = rightSec + ("right".equals(currentSide) ? addNow : 0);
            tvLeftTime.setText(TimeUtils.formatStopwatch(l));
            tvRightTime.setText(TimeUtils.formatStopwatch(r));
        }
    }

    private void finishFeeding() {
        long now = System.currentTimeMillis();
        int totalSec = Math.max(1, (int)((now - startedAt) / 1000));

        if ("breast".equals(kind)) {
            int add = (int)((now - sideSwitchedAt) / 1000);
            if ("left".equals(currentSide))  leftSec  += add;
            else                             rightSec += add;
        }

        Feeding f = new Feeding(
            kind, startedAt, totalSec,
            leftSec, rightSec,
            "bottle".equals(kind) ? amountMl : 0
        );
        store.add(f);
        NotifyHelper.scheduleAlarm(this);
        vibrate();
        finish();
    }

    private void vibrate() {
        try {
            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null && store.isVibrateOn()) vib.vibrate(30);
        } catch (Exception e) { /* ok */ }
    }
}
