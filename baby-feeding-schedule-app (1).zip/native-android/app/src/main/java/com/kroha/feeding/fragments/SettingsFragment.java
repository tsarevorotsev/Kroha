package com.kroha.feeding.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.kroha.feeding.NotifyHelper;
import com.kroha.feeding.R;
import com.kroha.feeding.models.FeedingStore;
import com.kroha.feeding.models.TimeUtils;

public class SettingsFragment extends Fragment {

    private FeedingStore store;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup p, @Nullable Bundle s) {
        return inf.inflate(R.layout.fragment_settings, p, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        store = FeedingStore.get(requireContext());

        EditText etName = v.findViewById(R.id.et_name);
        etName.setText(store.getBabyName());
        etName.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) {}
            @Override public void afterTextChanged(Editable e) {
                store.setBabyName(e.toString().trim());
            }
        });

        // Interval
        TextView tvInt = v.findViewById(R.id.tv_interval);
        updateIntervalText(tvInt);
        v.findViewById(R.id.btn_int_minus).setOnClickListener(b -> {
            int cur = store.getIntervalMin();
            if (cur > 60) { store.setIntervalMin(cur - 15); updateIntervalText(tvInt); }
        });
        v.findViewById(R.id.btn_int_plus).setOnClickListener(b -> {
            int cur = store.getIntervalMin();
            if (cur < 480) { store.setIntervalMin(cur + 15); updateIntervalText(tvInt); }
        });

        // Toggles
        Switch swNotify = v.findViewById(R.id.sw_notify);
        swNotify.setChecked(store.isNotifyOn());
        swNotify.setOnCheckedChangeListener((c, on) -> {
            store.setNotifyOn(on);
            if (on) NotifyHelper.scheduleAlarm(requireContext());
            else    NotifyHelper.cancelAlarm(requireContext());
        });

        Switch swVibrate = v.findViewById(R.id.sw_vibrate);
        swVibrate.setChecked(store.isVibrateOn());
        swVibrate.setOnCheckedChangeListener((c, on) -> store.setVibrateOn(on));

        Switch swSound = v.findViewById(R.id.sw_sound);
        swSound.setChecked(store.isSoundOn());
        swSound.setOnCheckedChangeListener((c, on) -> store.setSoundOn(on));

        // Clear
        v.findViewById(R.id.btn_clear).setOnClickListener(b ->
            new AlertDialog.Builder(requireContext())
                .setTitle("Очистить историю?")
                .setMessage("Все записи о кормлениях будут удалены.")
                .setPositiveButton("Удалить", (d, w) -> store.clearAll())
                .setNegativeButton("Отмена", null)
                .show()
        );
    }

    private void updateIntervalText(TextView tv) {
        int min = store.getIntervalMin();
        tv.setText(TimeUtils.formatGap(min * 60000L));
    }
}
