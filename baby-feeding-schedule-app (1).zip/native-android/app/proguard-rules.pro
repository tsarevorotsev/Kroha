# Keep Gson model classes
-keep class com.kroha.feeding.models.** { *; }
-keepattributes Signature
