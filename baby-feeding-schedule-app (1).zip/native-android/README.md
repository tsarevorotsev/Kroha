# 🍼 Кроха — нативное Android-приложение (Java)

## Компиляция в Android Code Studio (мобильная IDE)

### Шаг 1 — Создать проект
1. Откройте Android Code Studio
2. **New Project → Empty Activity**
3. Package name: `com.kroha.feeding`
4. Language: **Java**
5. Min SDK: **24**

### Шаг 2 — Скопировать файлы
Замените **все** стандартные файлы на файлы из этого проекта:

```
Что скопировать                      →  Куда положить
─────────────────────────────────────────────────────────────
settings.gradle                      →  корень проекта
build.gradle                         →  корень проекта
gradle.properties                    →  корень проекта
app/build.gradle                     →  app/build.gradle
app/proguard-rules.pro               →  app/proguard-rules.pro
app/src/main/AndroidManifest.xml     →  app/src/main/
app/src/main/java/com/kroha/feeding/ →  ВСЕ .java файлы
app/src/main/res/                    →  ВСЕ папки res/
```

### Шаг 3 — Структура файлов

```
app/src/main/
├── AndroidManifest.xml
├── java/com/kroha/feeding/
│   ├── App.java                    ← Application (каналы)
│   ├── MainActivity.java           ← Главный экран + навигация
│   ├── ActiveFeedingActivity.java  ← Секундомер кормления
│   ├── SettingsActivity.java
│   ├── NotifyHelper.java           ← Нативные будильники
│   ├── adapters/
│   │   └── FeedingAdapter.java     ← Список истории
│   ├── fragments/
│   │   ├── HomeFragment.java       ← Главная с таймером
│   │   ├── HistoryFragment.java    ← История по дням
│   │   └── SettingsFragment.java   ← Настройки
│   ├── models/
│   │   ├── Feeding.java            ← Модель кормления
│   │   ├── FeedingStore.java       ← Хранилище (SharedPrefs)
│   │   └── TimeUtils.java          ← Утилиты времени
│   └── receivers/
│       ├── AlarmReceiver.java      ← Приёмник будильника
│       └── BootReceiver.java       ← Восстановление после ребута
└── res/
    ├── color/
    │   └── bottom_nav_color.xml
    ├── drawable/
    │   ├── bg_gradient.xml
    │   ├── btn_coral.xml
    │   ├── btn_white_round.xml
    │   ├── card_bg.xml
    │   ├── chip_bg.xml
    │   ├── circle_coral.xml
    │   ├── dark_card_bg.xml
    │   ├── ic_launcher_foreground.xml
    │   ├── ic_notify.xml
    │   ├── kind_bottle_bg.xml
    │   ├── kind_breast_bg.xml
    │   └── kind_solid_bg.xml
    ├── layout/
    │   ├── activity_active_feeding.xml
    │   ├── activity_main.xml
    │   ├── activity_settings.xml
    │   ├── dialog_pick_type.xml
    │   ├── fragment_history.xml
    │   ├── fragment_home.xml
    │   ├── fragment_settings.xml
    │   ├── item_day_header.xml
    │   └── item_feeding.xml
    ├── menu/
    │   └── bottom_nav.xml
    ├── mipmap-hdpi/
    │   └── ic_launcher.xml
    └── values/
        ├── colors.xml
        ├── strings.xml
        └── styles.xml
```

### Шаг 4 — Собрать
Нажмите **Build** или **Run ▶** в Android Code Studio.

## Что внутри

| Функция | Описание |
|---------|----------|
| ⏱ Таймер | Обратный отсчёт до следующего кормления |
| 🤱 Грудь | Секундомер + трекинг левой/правой |
| 🍼 Бутылочка | Секундомер + объём в мл |
| 🥣 Прикорм | Быстрая запись в граммах |
| 📋 История | Список по дням с удалением |
| 🔔 Уведомления | AlarmManager — работает даже при закрытом приложении |
| 📱 После перезагрузки | BootReceiver восстанавливает будильник |
| 💾 Данные | SharedPreferences + Gson |
| ⚙️ Настройки | Интервал, имя, вибрация, звук |

## Зависимости (app/build.gradle)
- androidx.appcompat
- com.google.android.material
- androidx.recyclerview
- com.google.code.gson

Всё подтянется автоматически при первой сборке (нужен интернет).
