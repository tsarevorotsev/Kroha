# 📱 Как собрать APK файл приложения «Кроха»

Проект уже полностью готов — папка `android/` содержит
готовый Android-проект. Нужно только открыть и нажать Build.

---

## Способ 1 — Android Studio (на компьютере) ✅ Рекомендуется

### Что нужно скачать
- **Android Studio** → https://developer.android.com/studio (бесплатно)

### Шаги

1. **Откройте проект**
   - Запустите Android Studio
   - File → Open → выберите папку **`android/`** внутри нашего проекта
   - Подождите пока синхронизируется Gradle (1-3 мин, нужен интернет)

2. **Соберите APK**
   - Верхнее меню: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - Подождите 2-5 минут

3. **Найдите готовый APK**
   - Появится уведомление «APK generated» → нажмите **locate**
   - Файл будет здесь:
     ```
     android/app/build/outputs/apk/debug/app-debug.apk
     ```

4. **Установите на телефон**
   - Перекиньте `app-debug.apk` на телефон (через USB, Telegram себе, Google Drive)
   - На телефоне: Настройки → Безопасность → **Разрешить установку из неизвестных источников**
   - Откройте APK → Установить

---

## Способ 2 — Командная строка (без GUI)

Если у вас настроен Android SDK:

```bash
cd android
./gradlew assembleDebug
```

APK будет в: `android/app/build/outputs/apk/debug/app-debug.apk`

Для релизного APK (подписанного):
```bash
./gradlew assembleRelease
```

---

## Способ 3 — GitHub Actions (автосборка в облаке) ☁️

Создайте файл `.github/workflows/build.yml` — GitHub сам соберёт APK
и прикрепит его к релизу. Попросите добавить этот файл.

---

## Что получается в APK

| Функция | Работает |
|---------|----------|
| Таймер кормления | ✅ |
| Грудь (лево/право) | ✅ |
| Бутылочка с объёмом | ✅ |
| Прикорм | ✅ |
| История по дням | ✅ |
| Статистика 7 дней | ✅ |
| Напоминания внутри приложения | ✅ |
| Вибрация | ✅ |
| Звук | ✅ |
| Данные сохраняются | ✅ (localStorage) |
| Работает офлайн | ✅ |
| Тёмная строка состояния | ✅ кремовый цвет |

---

## Структура Android-проекта

```
android/
├── app/
│   ├── src/main/
│   │   ├── assets/public/     ← само веб-приложение (index.html)
│   │   ├── AndroidManifest.xml
│   │   └── res/
│   │       ├── values/colors.xml     ← цвет #FF7A5C (коралловый)
│   │       ├── values/styles.xml     ← тема без ActionBar
│   │       └── drawable/splash.xml  ← сплэш-экран
│   └── build.gradle
├── variables.gradle   ← minSdk=23 (Android 6.0+)
└── build.gradle
```

---

## Параметры приложения

- **Package:** `com.kroha.feeding`
- **Version:** 1.0
- **Min Android:** 6.0 (API 23) — поддерживает 98% устройств
- **Target Android:** 14 (API 35)
- **Размер APK:** ~5-8 МБ

---

## Если Gradle не синхронизируется

1. File → Invalidate Caches → Invalidate and Restart
2. Проверьте интернет — нужно скачать зависимости (~200 МБ при первом запуске)
3. Убедитесь что установлен **JDK 17+** (Android Studio включает его)
