export type NotifyPermission = 'granted' | 'denied' | 'default' | 'unsupported';

export function notifyPermission(): NotifyPermission {
  if (typeof Notification === 'undefined') return 'unsupported';
  return Notification.permission;
}

export async function requestNotifyPermission(): Promise<NotifyPermission> {
  if (typeof Notification === 'undefined') return 'unsupported';
  try {
    return await Notification.requestPermission();
  } catch {
    return Notification.permission;
  }
}

let audioCtx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  try {
    if (!audioCtx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AC) return null;
      audioCtx = new AC();
    }
    if (audioCtx.state === 'suspended') void audioCtx.resume();
    return audioCtx;
  } catch {
    return null;
  }
}

/** Мягкий двухтональный сигнал без внешних файлов */
export function playDing() {
  const ctx = getCtx();
  if (!ctx) return;
  try {
    const notes = [880, 1174.66];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const t = ctx.currentTime + i * 0.18;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.18, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.6);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.65);
    });
  } catch {
    /* noop */
  }
}

export function buzz(pattern: number | number[]) {
  try {
    if ('vibrate' in navigator) navigator.vibrate(pattern);
  } catch {
    /* noop */
  }
}

declare global {
  interface Window {
    Kroha?: { notify?: (title: string, body: string) => void };
  }
}

export function fireSystemNotification(title: string, body: string) {
  // Если приложение запущено внутри Android WebView-обёртки —
  // используем нативные уведомления через JS-мост.
  try {
    const bridge = window.Kroha;
    if (bridge && typeof bridge.notify === 'function') {
      bridge.notify(title, body);
      return;
    }
  } catch {
    /* noop */
  }
  if (notifyPermission() !== 'granted') return;
  try {
    new Notification(title, { body, tag: 'kroha-feeding', silent: true });
  } catch {
    /* noop */
  }
}

/** true, если приложение запущено внутри Android-обёртки */
export function isNativeWrapper(): boolean {
  try {
    return typeof window.Kroha !== 'undefined';
  } catch {
    return false;
  }
}
