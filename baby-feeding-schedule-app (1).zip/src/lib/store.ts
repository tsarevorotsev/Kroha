import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type FeedingKind = 'breast' | 'bottle' | 'solid';

export interface Feeding {
  id: string;
  kind: FeedingKind;
  startedAt: number;
  durationSec: number;
  leftSec: number;
  rightSec: number;
  /** мл для бутылочки, граммы для прикорма */
  amount: number;
}

export interface ActiveBreast {
  kind: 'breast';
  startedAt: number;
  side: 'left' | 'right';
  sideSwitchedAt: number;
  leftSec: number;
  rightSec: number;
}

export interface ActiveBottle {
  kind: 'bottle';
  startedAt: number;
  amountMl: number;
}

export type ActiveFeeding = ActiveBreast | ActiveBottle;

export interface Settings {
  intervalMin: number;
  remindMin: number;
  notifications: boolean;
  vibrate: boolean;
  sound: boolean;
  babyName: string;
  babyBirth: string;
}

interface State {
  feedings: Feeding[];
  active: ActiveFeeding | null;
  settings: Settings;
  notified: Record<string, boolean>;

  startBreast: (side: 'left' | 'right') => void;
  switchSide: () => void;
  startBottle: () => void;
  setBottleMl: (ml: number) => void;
  finishActive: () => void;
  cancelActive: () => void;
  addSolid: (grams: number) => void;
  addPast: (f: Omit<Feeding, 'id'>) => void;
  removeFeeding: (id: string) => void;
  updateSettings: (s: Partial<Settings>) => void;
  markNotified: (key: string) => void;
  clearAll: () => void;
}

const uid = () =>
  Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

const sortDesc = (list: Feeding[]) =>
  [...list].sort((a, b) => b.startedAt - a.startedAt);

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      feedings: [],
      active: null,
      notified: {},
      settings: {
        intervalMin: 180,
        remindMin: 10,
        notifications: false,
        vibrate: true,
        sound: true,
        babyName: 'Малыш',
        babyBirth: '',
      },

      startBreast: (side) =>
        set({
          active: {
            kind: 'breast',
            startedAt: Date.now(),
            side,
            sideSwitchedAt: Date.now(),
            leftSec: 0,
            rightSec: 0,
          },
        }),

      switchSide: () => {
        const a = get().active;
        if (!a || a.kind !== 'breast') return;
        const now = Date.now();
        const add = Math.round((now - a.sideSwitchedAt) / 1000);
        set({
          active: {
            ...a,
            side: a.side === 'left' ? 'right' : 'left',
            sideSwitchedAt: now,
            leftSec: a.leftSec + (a.side === 'left' ? add : 0),
            rightSec: a.rightSec + (a.side === 'right' ? add : 0),
          },
        });
      },

      startBottle: () =>
        set({ active: { kind: 'bottle', startedAt: Date.now(), amountMl: 120 } }),

      setBottleMl: (ml) => {
        const a = get().active;
        if (!a || a.kind !== 'bottle') return;
        set({ active: { ...a, amountMl: Math.max(0, Math.min(400, Math.round(ml))) } });
      },

      finishActive: () => {
        const a = get().active;
        if (!a) return;
        const now = Date.now();
        let entry: Feeding;
        if (a.kind === 'breast') {
          const add = Math.round((now - a.sideSwitchedAt) / 1000);
          const leftSec = a.leftSec + (a.side === 'left' ? add : 0);
          const rightSec = a.rightSec + (a.side === 'right' ? add : 0);
          entry = {
            id: uid(),
            kind: 'breast',
            startedAt: a.startedAt,
            durationSec: Math.max(1, Math.round((now - a.startedAt) / 1000)),
            leftSec,
            rightSec,
            amount: 0,
          };
        } else {
          entry = {
            id: uid(),
            kind: 'bottle',
            startedAt: a.startedAt,
            durationSec: Math.max(1, Math.round((now - a.startedAt) / 1000)),
            leftSec: 0,
            rightSec: 0,
            amount: a.amountMl,
          };
        }
        set({
          active: null,
          notified: {},
          feedings: sortDesc([entry, ...get().feedings]),
        });
      },

      cancelActive: () => set({ active: null }),

      addSolid: (grams) => {
        const entry: Feeding = {
          id: uid(),
          kind: 'solid',
          startedAt: Date.now(),
          durationSec: 0,
          leftSec: 0,
          rightSec: 0,
          amount: grams,
        };
        set({
          notified: {},
          feedings: sortDesc([entry, ...get().feedings]),
        });
      },

      addPast: (f) => {
        set({
          notified: {},
          feedings: sortDesc([{ ...f, id: uid() }, ...get().feedings]),
        });
      },

      removeFeeding: (id) =>
        set({ feedings: get().feedings.filter((f) => f.id !== id) }),

      updateSettings: (s) => set({ settings: { ...get().settings, ...s } }),

      markNotified: (key) =>
        set({ notified: { ...get().notified, [key]: true } }),

      clearAll: () => set({ feedings: [], active: null, notified: {} }),
    }),
    {
      name: 'kroha-feeding-v1',
      version: 1,
    },
  ),
);

/** Время окончания последнего кормления (для расчёта следующего) */
export function lastFeedingEnd(f: Feeding[]): number | null {
  if (!f.length) return null;
  const last = f[0];
  return last.startedAt + last.durationSec * 1000;
}
