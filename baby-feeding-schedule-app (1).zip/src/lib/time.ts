export const MONTHS_SHORT = [
  'янв', 'фев', 'мар', 'апр', 'мая', 'июн',
  'июл', 'авг', 'сен', 'окт', 'ноя', 'дек',
];
export const MONTHS_GEN = [
  'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
  'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
];
export const WEEKDAYS = [
  'воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота',
];

export const pad2 = (n: number) => String(n).padStart(2, '0');

export function fmtClock(ts: number): string {
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

/** "1 ч 05 мин" | "12 мин" | "<1 мин" */
export function fmtDuration(sec: number): string {
  const totalMin = Math.round(sec / 60);
  if (totalMin < 1) return '<1 мин';
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h === 0) return `${m} мин`;
  return `${h} ч ${pad2(m)} мин`;
}

export function fmtGap(ms: number): string {
  const totalMin = Math.floor(ms / 60000);
  if (totalMin < 1) return '<1 мин';
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h === 0) return `${m} мин`;
  return `${h} ч ${pad2(m)} мин`;
}

export function fmtStopwatch(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  if (h > 0) return `${pad2(h)}:${pad2(m)}:${pad2(ss)}`;
  return `${pad2(m)}:${pad2(ss)}`;
}

export function startOfDay(ts: number): number {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function dayLabel(ts: number): string {
  const today = startOfDay(Date.now());
  const day = startOfDay(ts);
  if (day === today) return 'Сегодня';
  if (day === today - 86400000) return 'Вчера';
  const d = new Date(ts);
  return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`;
}

export function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export function plural(n: number, one: string, few: string, many: string): string {
  const n10 = n % 10;
  const n100 = n % 100;
  if (n10 === 1 && n100 !== 11) return one;
  if (n10 >= 2 && n10 <= 4 && (n100 < 10 || n100 >= 20)) return few;
  return many;
}

/** Возраст по дате рождения: "4 мес 12 дн" */
export function ageFromBirth(iso: string): string | null {
  if (!iso) return null;
  const b = new Date(iso + 'T00:00:00');
  if (Number.isNaN(b.getTime())) return null;
  const now = new Date();
  if (b.getTime() > now.getTime()) return null;
  let months =
    (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
  const dayOfBirth = b.getDate();
  let days = now.getDate() - dayOfBirth;
  if (days < 0) {
    months -= 1;
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    days += prevMonth;
  }
  if (months < 0) return null;
  if (months === 0) return `${days} ${plural(days, 'день', 'дня', 'дней')}`;
  return `${months} ${plural(months, 'мес', 'мес', 'мес')} ${days} ${plural(days, 'д', 'д', 'д')}`;
}

export function greeting(hour: number): string {
  if (hour < 5) return 'Доброй ночи';
  if (hour < 12) return 'Доброе утро';
  if (hour < 18) return 'Добрый день';
  return 'Добрый вечер';
}
