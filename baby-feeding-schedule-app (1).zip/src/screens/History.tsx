import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Timer, Milk, Apple, CalendarHeart, Inbox } from 'lucide-react';
import { useStore, type FeedingKind } from '../lib/store';
import { fmtClock, fmtDuration, dayLabel, startOfDay, plural } from '../lib/time';
import {
  Card,
  Sheet,
  Segmented,
  Stepper,
  GradientButton,
  ScreenHeader,
  KIND_META,
} from '../components/ui';
import { buzz } from '../lib/notify';
import type { Feeding } from '../lib/store';

function details(f: Feeding): string {
  if (f.kind === 'breast') {
    const parts: string[] = [fmtDuration(f.durationSec)];
    if (f.leftSec > 0 && f.rightSec > 0)
      parts.push(`Л ${fmtDuration(f.leftSec)} · П ${fmtDuration(f.rightSec)}`);
    else if (f.leftSec > 0) parts.push('левая');
    else if (f.rightSec > 0) parts.push('правая');
    return parts.join(' · ');
  }
  if (f.kind === 'bottle') return `${f.amount} мл · ${fmtDuration(f.durationSec)}`;
  return `${f.amount} г`;
}

export function HistoryScreen() {
  const feedings = useStore((s) => s.feedings);
  const removeFeeding = useStore((s) => s.removeFeeding);
  const addPast = useStore((s) => s.addPast);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [kind, setKind] = useState<FeedingKind>('breast');
  const [minsAgo, setMinsAgo] = useState(30);
  const [durMin, setDurMin] = useState(15);
  const [ml, setMl] = useState(120);
  const [grams, setGrams] = useState(80);

  const days = useMemo(() => {
    const map = new Map<number, Feeding[]>();
    for (const f of feedings) {
      const key = startOfDay(f.startedAt);
      const arr = map.get(key) ?? [];
      arr.push(f);
      map.set(key, arr);
    }
    return [...map.entries()].sort((a, b) => b[0] - a[0]);
  }, [feedings]);

  const save = () => {
    addPast({
      kind,
      startedAt: Date.now() - minsAgo * 60000,
      durationSec: kind === 'solid' ? 0 : durMin * 60,
      leftSec: kind === 'breast' ? Math.round((durMin * 60) / 2) : 0,
      rightSec: kind === 'breast' ? Math.round((durMin * 60) / 2) : 0,
      amount: kind === 'bottle' ? ml : kind === 'solid' ? grams : 0,
    });
    setSheetOpen(false);
    buzz([25, 50, 25]);
  };

  return (
    <div>
      <ScreenHeader
        title="История"
        subtitle={
          feedings.length
            ? `${feedings.length} ${plural(feedings.length, 'запись', 'записи', 'записей')}`
            : 'записей пока нет'
        }
        right={
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setSheetOpen(true)}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-[linear-gradient(140deg,#FFB98C,#F25C40)] text-white shadow-pop"
            aria-label="Добавить вручную"
          >
            <Plus size={22} strokeWidth={2.8} />
          </motion.button>
        }
      />

      {days.length === 0 && (
        <Card className="flex flex-col items-center py-10 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-cream-200">
            <Inbox size={28} className="text-ink-500" />
          </span>
          <h3 className="mt-4 font-black">Пока пусто</h3>
          <p className="mt-1 max-w-[15rem] text-sm font-semibold text-ink-500">
            Начните кормление на главном экране или добавьте запись вручную.
          </p>
        </Card>
      )}

      <div className="flex flex-col gap-6">
        {days.map(([day, items]) => {
          const breastSec = items
            .filter((f) => f.kind === 'breast')
            .reduce((a, f) => a + f.durationSec, 0);
          const bottleMl = items
            .filter((f) => f.kind === 'bottle')
            .reduce((a, f) => a + f.amount, 0);
          const solidG = items.filter((f) => f.kind === 'solid').reduce((a, f) => a + f.amount, 0);
          return (
            <div key={day}>
              <div className="mb-2.5 flex items-baseline justify-between px-1">
                <h3 className="text-[15px] font-black">{dayLabel(day)}</h3>
                <span className="text-xs font-bold text-ink-500">
                  {items.length} · {breastSec ? fmtDuration(breastSec) + ' грудь' : ''}
                  {breastSec && bottleMl ? ' · ' : ''}
                  {bottleMl ? bottleMl + ' мл' : ''}
                  {(breastSec || bottleMl) && solidG ? ' · ' : ''}
                  {solidG ? solidG + ' г' : ''}
                </span>
              </div>
              <div className="flex flex-col gap-2.5">
                <AnimatePresence initial={false}>
                  {items.map((f) => {
                    const meta = KIND_META[f.kind];
                    const Icon = meta.icon;
                    return (
                      <motion.div
                        key={f.id}
                        layout
                        initial={{ opacity: 0, y: 14 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.18 } }}
                        transition={{ type: 'spring', damping: 26, stiffness: 320 }}
                        className="flex items-center gap-3.5 rounded-3xl bg-white/85 p-4 shadow-card backdrop-blur-xl"
                      >
                        <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${meta.tile}`}>
                          <Icon size={22} className={meta.iconColor} strokeWidth={2.2} />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="text-[15px] font-extrabold">
                            {meta.label}
                            <span className="ml-2 font-display text-[13px] font-bold text-ink-500 tabular-nums">
                              {fmtClock(f.startedAt)}
                            </span>
                          </div>
                          <div className="truncate text-[13px] font-bold text-ink-500">{details(f)}</div>
                        </div>
                        <motion.button
                          whileTap={{ scale: 0.85 }}
                          onClick={() => {
                            removeFeeding(f.id);
                            buzz(15);
                          }}
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-cream-100 text-ink-300 transition-colors active:bg-coral-100 active:text-coral-600"
                          aria-label="Удалить"
                        >
                          <Trash2 size={16} strokeWidth={2.4} />
                        </motion.button>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          );
        })}
      </div>

      {/* добавление вручную */}
      <Sheet open={sheetOpen} onClose={() => setSheetOpen(false)} title="Добавить кормление">
        <Segmented
          className="mb-5"
          value={kind}
          onChange={(v) => setKind(v)}
          options={[
            { value: 'breast', label: <span className="flex items-center gap-1"><Timer size={14} />Грудь</span> },
            { value: 'bottle', label: <span className="flex items-center gap-1"><Milk size={14} />Смесь</span> },
            { value: 'solid', label: <span className="flex items-center gap-1"><Apple size={14} />Прикорм</span> },
          ]}
        />

        <div className="mb-4">
          <div className="mb-2 text-center text-xs font-black tracking-wider text-ink-500 uppercase">
            Когда закончилось
          </div>
          <Stepper value={minsAgo} onChange={setMinsAgo} step={5} min={0} max={1440} unit="мин назад" />
        </div>

        {kind !== 'solid' && (
          <div className="mb-4">
            <div className="mb-2 text-center text-xs font-black tracking-wider text-ink-500 uppercase">
              Длительность
            </div>
            <Stepper value={durMin} onChange={setDurMin} step={1} min={1} max={120} unit="мин" />
          </div>
        )}

        {kind === 'bottle' && (
          <div className="mb-4">
            <div className="mb-2 text-center text-xs font-black tracking-wider text-ink-500 uppercase">
              Объём
            </div>
            <Stepper value={ml} onChange={setMl} step={10} min={10} max={400} unit="мл" />
          </div>
        )}

        {kind === 'solid' && (
          <div className="mb-4">
            <div className="mb-2 text-center text-xs font-black tracking-wider text-ink-500 uppercase">
              Количество
            </div>
            <Stepper value={grams} onChange={setGrams} step={10} min={10} max={400} unit="г" />
          </div>
        )}

        <GradientButton onClick={save} tone="mint">
          <CalendarHeart size={19} />
          Сохранить запись
        </GradientButton>
      </Sheet>
    </div>
  );
}
