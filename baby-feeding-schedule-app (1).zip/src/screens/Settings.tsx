import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BellRing,
  BellOff,
  Vibrate,
  Volume2,
  VolumeX,
  Trash2,
  Baby,
  Hourglass,
  Heart,
  ShieldAlert,
} from 'lucide-react';
import { useStore } from '../lib/store';
import { fmtGap, ageFromBirth } from '../lib/time';
import { Card, ScreenHeader, Stepper } from '../components/ui';
import { requestNotifyPermission, notifyPermission, buzz, playDing } from '../lib/notify';
import { cn } from '../utils/cn';

const INTERVALS = [90, 120, 150, 180, 210, 240];
const REMIND = [0, 5, 10, 15];

function Toggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn(
        'relative h-8 w-14 shrink-0 rounded-full transition-colors duration-300',
        checked ? 'bg-[linear-gradient(135deg,#FF9D6C,#F25C40)]' : 'bg-cream-200',
      )}
      role="switch"
      aria-checked={checked}
    >
      <motion.span
        animate={{ x: checked ? 26 : 3 }}
        transition={{ type: 'spring', damping: 22, stiffness: 350 }}
        className="absolute top-[3px] left-0 h-[26px] w-[26px] rounded-full bg-white shadow-md"
      />
    </button>
  );
}

function Row({
  icon,
  title,
  sub,
  right,
}: {
  icon: React.ReactNode;
  title: string;
  sub?: string;
  right: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 py-3.5 first:pt-0 last:pb-0">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-cream-100">
        {icon}
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-[15px] font-extrabold">{title}</div>
        {sub && <div className="text-xs leading-snug font-semibold text-ink-500">{sub}</div>}
      </div>
      {right}
    </div>
  );
}

export function SettingsScreen() {
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const clearAll = useStore((s) => s.clearAll);
  const feedings = useStore((s) => s.feedings);

  const [permNote, setPermNote] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const age = ageFromBirth(settings.babyBirth);

  const onToggleNotifications = async (on: boolean) => {
    if (!on) {
      updateSettings({ notifications: false });
      return;
    }
    const p = await requestNotifyPermission();
    if (p === 'granted') {
      updateSettings({ notifications: true });
      setPermNote(null);
      if (settings.sound) playDing();
      if (settings.vibrate) buzz([20, 40, 20]);
    } else if (p === 'denied') {
      setPermNote('Уведомления заблокированы. Разрешите их в настройках браузера/системы.');
      updateSettings({ notifications: false });
    } else if (p === 'unsupported') {
      setPermNote('Этот браузер не поддерживает уведомления — подойдёт напоминалка внутри приложения.');
      updateSettings({ notifications: true });
    }
  };

  return (
    <div>
      <ScreenHeader title="Настройки" subtitle="режим и напоминания под ваш малыш" />

      {/* карточка малыша */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <div className="mb-3 flex items-center gap-2">
            <Baby size={15} className="text-coral-500" />
            <span className="text-xs font-black tracking-wider text-ink-500 uppercase">Малыш</span>
            {age && (
              <span className="ml-auto rounded-full bg-coral-100 px-2.5 py-1 text-[11px] font-extrabold text-coral-600">
                {age}
              </span>
            )}
          </div>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-bold text-ink-500">Имя</span>
            <input
              value={settings.babyName}
              onChange={(e) => updateSettings({ babyName: e.target.value.slice(0, 24) })}
              placeholder="Как зовут малыша?"
              className="w-full rounded-2xl bg-cream-100 px-4 py-3 text-[15px] font-bold outline-none transition-shadow placeholder:text-ink-300 focus:ring-4 focus:ring-coral-200"
            />
          </label>
          <label className="mt-3 block">
            <span className="mb-1.5 block text-[13px] font-bold text-ink-500">Дата рождения</span>
            <input
              type="date"
              value={settings.babyBirth}
              onChange={(e) => updateSettings({ babyBirth: e.target.value })}
              className="w-full rounded-2xl bg-cream-100 px-4 py-3 text-[15px] font-bold outline-none focus:ring-4 focus:ring-coral-200"
            />
          </label>
        </Card>
      </motion.div>

      {/* интервал */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 }}>
        <Card className="mt-4">
          <div className="mb-1 flex items-center gap-2">
            <Hourglass size={15} className="text-lilac-500" />
            <span className="text-xs font-black tracking-wider text-ink-500 uppercase">
              Интервал кормления
            </span>
          </div>
          <div className="mt-2 mb-4 flex flex-wrap gap-2">
            {INTERVALS.map((m) => (
              <button
                key={m}
                onClick={() => {
                  updateSettings({ intervalMin: m });
                  buzz(10);
                }}
                className={cn(
                  'rounded-full px-4 py-2 text-sm font-extrabold transition-colors',
                  settings.intervalMin === m
                    ? 'bg-[linear-gradient(135deg,#FF9D6C,#F25C40)] text-white shadow-pop'
                    : 'bg-cream-100 text-ink-500',
                )}
              >
                {m % 60 === 0 ? `${m / 60} ч` : `${Math.floor(m / 60)},5 ч`}
              </button>
            ))}
          </div>
          <Stepper
            value={settings.intervalMin}
            onChange={(v) => updateSettings({ intervalMin: v })}
            step={15}
            min={60}
            max={480}
            unit="мин"
          />
          <p className="mt-3 text-center text-xs font-semibold text-ink-500">
            Сейчас: кормить каждые {fmtGap(settings.intervalMin * 60000)}
          </p>
        </Card>
      </motion.div>

      {/* уведомления */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
        <Card className="mt-4">
          <div className="mb-2 flex items-center gap-2">
            <BellRing size={15} className="text-coral-500" />
            <span className="text-xs font-black tracking-wider text-ink-500 uppercase">
              Напоминания
            </span>
          </div>

          <Row
            icon={settings.notifications ? <BellRing size={19} className="text-coral-500" /> : <BellOff size={19} className="text-ink-500" />}
            title="Уведомления"
            sub={
              settings.notifications
                ? notifyPermission() === 'granted'
                  ? 'Включены: системные + внутри приложения'
                  : 'Включены внутри приложения'
                : 'Выключены'
            }
            right={<Toggle checked={settings.notifications} onChange={onToggleNotifications} />}
          />
          {permNote && (
            <p className="mb-3 flex items-start gap-1.5 rounded-xl bg-sun-50 p-2.5 text-xs leading-snug font-bold text-sun-500">
              <ShieldAlert size={14} className="mt-px shrink-0" />
              {permNote}
            </p>
          )}

          {settings.notifications && (
            <div className="mb-2">
              <div className="mb-2 text-xs font-bold text-ink-500">Предупреждать заранее</div>
              <div className="flex gap-2">
                {REMIND.map((m) => (
                  <button
                    key={m}
                    onClick={() => {
                      updateSettings({ remindMin: m });
                      buzz(10);
                    }}
                    className={cn(
                      'flex-1 rounded-full px-2 py-2 text-[13px] font-extrabold transition-colors',
                      settings.remindMin === m
                        ? 'bg-coral-500 text-white'
                        : 'bg-cream-100 text-ink-500',
                    )}
                  >
                    {m === 0 ? 'в момент' : `за ${m} мин`}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-1 border-t border-cream-200">
            <Row
              icon={settings.sound ? <Volume2 size={19} className="text-mint-500" /> : <VolumeX size={19} className="text-ink-500" />}
              title="Звук"
              sub="мягкий сигнал при напоминании"
              right={
                <Toggle
                  checked={settings.sound}
                  onChange={(v) => {
                    updateSettings({ sound: v });
                    if (v) playDing();
                  }}
                />
              }
            />
            <Row
              icon={<Vibrate size={19} className="text-lilac-500" />}
              title="Вибрация"
              sub="на поддерживаемых устройствах"
              right={
                <Toggle
                  checked={settings.vibrate}
                  onChange={(v) => {
                    updateSettings({ vibrate: v });
                    if (v) buzz([30, 50, 30]);
                  }}
                />
              }
            />
          </div>
        </Card>
      </motion.div>

      {/* данные */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
        <Card className="mt-4">
          <Row
            icon={<Trash2 size={19} className="text-coral-600" />}
            title="Очистить историю"
            sub={feedings.length ? 'Все записи о кормлениях будут удалены' : 'Записей нет'}
            right={
              <motion.button
                whileTap={{ scale: 0.94 }}
                onClick={() => {
                  if (!confirmClear) {
                    setConfirmClear(true);
                    setTimeout(() => setConfirmClear(false), 3000);
                  } else {
                    clearAll();
                    setConfirmClear(false);
                    buzz([40, 60, 40]);
                  }
                }}
                className={cn(
                  'rounded-full px-4 py-2 text-[13px] font-extrabold transition-colors',
                  confirmClear ? 'bg-coral-600 text-white' : 'bg-coral-100 text-coral-600',
                )}
              >
                {confirmClear ? 'Точно?' : 'Удалить'}
              </motion.button>
            }
          />
        </Card>
      </motion.div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.26 }}
        className="mt-6 flex items-center justify-center gap-1.5 text-center text-xs font-bold text-ink-500"
      >
        Сделано с <Heart size={12} className="fill-coral-500 text-coral-500" /> для мам — Кроха 1.0
      </motion.p>
    </div>
  );
}
