import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Play,
  AlarmClock,
  Sparkles,
  ChevronRight,
  Timer,
  Milk,
  Baby as BabyIcon,
  CalendarHeart,
} from 'lucide-react';
import { useStore, lastFeedingEnd } from '../lib/store';
import {
  fmtClock,
  fmtGap,
  fmtStopwatch,
  fmtDuration,
  greeting,
  ageFromBirth,
  startOfDay,
  WEEKDAYS,
  MONTHS_GEN,
  capitalize,
} from '../lib/time';
import {
  Card,
  Ring,
  GradientButton,
  Sheet,
  SheetOption,
  Stepper,
  useNow,
  KIND_META,
} from '../components/ui';
import { buzz } from '../lib/notify';

const TIPS = [
  'Держите малыша вертикально «столбиком» 5–10 минут после кормления.',
  'При грудном вскармливании чередуйте сторону: начинайте с той, что была второй в прошлый раз.',
  'Ориентируйтесь на признаки голода: малыш причмокивает, ищет грудь, сует кулачки в рот.',
  'Тёплый душ и спокойная обстановка помогают кормить без спешки.',
  'Смесь храните не дольше 2 часов при комнатной температуре.',
  'Прикорм лучше давать до молока — так малыш охотнее пробует новое.',
  'Записывайте каждое кормление: ритм помогает заметить изменения аппетита.',
  'Ночью кормите в приглушённом свете, чтобы не сбивать режим сна.',
];

const fadeUp = {
  initial: { opacity: 0, y: 22 },
  animate: { opacity: 1, y: 0 },
};

export function HomeScreen() {
  const feedings = useStore((s) => s.feedings);
  const settings = useStore((s) => s.settings);
  const startBreast = useStore((s) => s.startBreast);
  const startBottle = useStore((s) => s.startBottle);
  const addSolid = useStore((s) => s.addSolid);

  const [sheet, setSheet] = useState<null | 'pick' | 'solid'>(null);
  const [grams, setGrams] = useState(80);

  const now = useNow(1000);
  const h = new Date(now).getHours();
  const d = new Date(now);

  const last = feedings[0];
  const lastEnd = lastFeedingEnd(feedings);
  const intervalMs = settings.intervalMin * 60000;
  const dueAt = lastEnd !== null ? lastEnd + intervalMs : null;
  const elapsed = lastEnd !== null ? now - lastEnd : 0;
  const remaining = dueAt !== null ? dueAt - now : 0;
  const overdue = remaining <= 0 && lastFeedingEnd(feedings) !== null;
  const progress = lastEnd !== null ? Math.min(1, elapsed / intervalMs) : 0;

  const today = startOfDay(now);
  const todayFeeds = feedings.filter((f) => f.startedAt >= today);
  const todayBreastSec = todayFeeds
    .filter((f) => f.kind === 'breast')
    .reduce((a, f) => a + f.durationSec, 0);
  const todayMl = todayFeeds
    .filter((f) => f.kind === 'bottle')
    .reduce((a, f) => a + f.amount, 0);

  const tip = TIPS[Math.floor(now / 86400000) % TIPS.length];
  const age = ageFromBirth(settings.babyBirth);

  const lastMeta = last ? KIND_META[last.kind] : null;

  return (
    <div>
      {/* шапка */}
      <motion.div {...fadeUp} transition={{ duration: 0.45 }} className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm font-bold text-ink-500">
            {capitalize(WEEKDAYS[d.getDay()])}, {d.getDate()} {MONTHS_GEN[d.getMonth()]}
          </p>
          <h1 className="mt-0.5 text-[1.7rem] leading-tight font-black tracking-tight">
            {greeting(h)}, {settings.babyName === 'Малыш' ? 'мама' : settings.babyName}!
          </h1>
        </div>
        <div className="relative">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[linear-gradient(140deg,#FFB98C,#F25C40)] shadow-pop">
            <BabyIcon size={26} className="text-white" strokeWidth={2.2} />
          </div>
          {age && (
            <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-white px-2 py-0.5 text-[10px] font-extrabold whitespace-nowrap text-coral-600 shadow-sm">
              {age}
            </span>
          )}
        </div>
      </motion.div>

      {/* герой-карточка с кольцом */}
      <motion.div {...fadeUp} transition={{ duration: 0.5, delay: 0.06 }}>
        <Card className="relative overflow-hidden p-6">
          <div className="pointer-events-none absolute -top-20 -right-20 h-44 w-44 rounded-full bg-coral-100/70 blur-2xl" />
          <div className="flex flex-col items-center">
            {last ? (
              <>
                <motion.div
                  animate={overdue ? { scale: [1, 1.03, 1] } : { scale: 1 }}
                  transition={overdue ? { repeat: Infinity, duration: 2.2, ease: 'easeInOut' } : {}}
                >
                  <Ring size={238} stroke={13} progress={progress} overdue={overdue}>
                    {overdue ? (
                      <>
                        <span className="animate-pulse-soft text-[11px] font-black tracking-[0.2em] text-coral-600 uppercase">
                          Пора кормить
                        </span>
                        <span className="font-display mt-1 text-[2.7rem] leading-none font-bold text-coral-600 tabular-nums">
                          +{fmtGap(-remaining)}
                        </span>
                        <span className="mt-2 text-xs font-bold text-ink-500">
                          сверх интервала {fmtGap(intervalMs)}
                        </span>
                      </>
                    ) : (
                      <>
                        <span className="text-[11px] font-black tracking-[0.2em] text-ink-500 uppercase">
                          До кормления
                        </span>
                        <span className="font-display mt-1 text-[2.7rem] leading-none font-bold tabular-nums">
                          {fmtStopwatch(Math.max(0, Math.floor(remaining / 1000)))}
                        </span>
                        <span className="mt-2 text-xs font-bold text-ink-500">
                          прошло {fmtGap(elapsed)} из {fmtGap(intervalMs)}
                        </span>
                      </>
                    )}
                  </Ring>
                </motion.div>

                {/* последнее кормление */}
                {lastMeta && (
                  <div className="mt-5 flex w-full items-center gap-3 rounded-2xl bg-cream-100/90 p-3">
                    <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${lastMeta.tile}`}>
                      <lastMeta.icon size={19} className={lastMeta.iconColor} />
                    </span>
                    <div className="flex-1 text-[13px] leading-snug font-bold text-ink-500">
                      Последнее: <span className="text-ink-900">{fmtClock(last.startedAt)}</span>
                      {' · '}
                      {last.kind === 'breast' && `${fmtDuration(last.durationSec)} у груди`}
                      {last.kind === 'bottle' && `${last.amount} мл`}
                      {last.kind === 'solid' && `${last.amount} г прикорма`}
                    </div>
                    <ChevronRight size={16} className="text-ink-300" />
                  </div>
                )}
              </>
            ) : (
              <div className="flex flex-col items-center py-6 text-center">
                <motion.div
                  animate={{ y: [0, -8, 0] }}
                  transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
                  className="flex h-24 w-24 items-center justify-center rounded-[2rem] bg-[linear-gradient(140deg,#FFB98C,#F25C40)] shadow-pop"
                >
                  <Timer size={44} className="text-white" strokeWidth={1.8} />
                </motion.div>
                <h2 className="mt-5 text-xl font-black">Начнём следить за кормлениями</h2>
                <p className="mt-1.5 max-w-[17rem] text-sm leading-relaxed font-semibold text-ink-500">
                  Нажмите «Начать кормление», а приложение напомнит, когда придёт время следующего.
                </p>
              </div>
            )}

            <div className="mt-5 w-full">
              <GradientButton
                onClick={() => {
                  setSheet('pick');
                  buzz(15);
                }}
              >
                <Play size={20} strokeWidth={2.8} />
                Начать кормление
              </GradientButton>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* прогноз */}
      {dueAt !== null && (
        <motion.div {...fadeUp} transition={{ duration: 0.5, delay: 0.12 }} className="mt-4">
          <div className="flex items-center gap-3.5 rounded-[1.75rem] bg-[linear-gradient(135deg,#4A3440,#33232E)] p-4.5 text-white shadow-soft">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/12">
              <AlarmClock size={21} className="text-sun-300" />
            </span>
            <div className="flex-1">
              <div className="text-[13px] font-bold text-white/70">Следующее кормление</div>
              <div className="text-[1.05rem] font-extrabold">
                {overdue
                  ? 'Прямо сейчас!'
                  : `в ${fmtClock(dueAt)} — через ${fmtGap(remaining)}`}
              </div>
            </div>
            {settings.notifications ? (
              <span className="rounded-full bg-mint-400/20 px-2.5 py-1 text-[11px] font-extrabold text-mint-300">
                напомним
              </span>
            ) : (
              <span className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-extrabold text-white/60">
                без уведомлений
              </span>
            )}
          </div>
        </motion.div>
      )}

      {/* сегодня */}
      <motion.div {...fadeUp} transition={{ duration: 0.5, delay: 0.18 }} className="mt-4">
        <div className="grid grid-cols-3 gap-3">
          <TodayStat icon={<BabyIcon size={13} />} label="Кормлений" value={String(todayFeeds.length)} />
          <TodayStat icon={<Timer size={13} />} label="У груди" value={todayBreastSec ? fmtDuration(todayBreastSec) : '—'} />
          <TodayStat icon={<Milk size={13} />} label="Из бутылочки" value={todayMl ? `${todayMl} мл` : '—'} />
        </div>
      </motion.div>

      {/* ритм дня */}
      {todayFeeds.length > 0 && (
        <motion.div {...fadeUp} transition={{ duration: 0.5, delay: 0.21 }} className="mt-4">
          <Card>
            <div className="mb-3 flex items-center justify-between">
              <span className="text-xs font-black tracking-wider text-ink-500 uppercase">
                Ритм дня
              </span>
              <span className="text-[11px] font-bold text-ink-300">00 — 24 ч</span>
            </div>
            <div className="relative h-3.5 rounded-full bg-cream-200/80">
              {todayFeeds.map((f) => {
                const d = new Date(f.startedAt);
                const pos = ((d.getHours() * 60 + d.getMinutes()) / 1440) * 100;
                const dot =
                  f.kind === 'breast' ? 'bg-coral-500' : f.kind === 'bottle' ? 'bg-mint-500' : 'bg-sun-500';
                return (
                  <motion.span
                    key={f.id}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', damping: 14, stiffness: 300 }}
                    className={`absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-white ${dot}`}
                    style={{ left: `${pos}%` }}
                    title={fmtClock(f.startedAt)}
                  />
                );
              })}
            </div>
            <div className="mt-2.5 flex items-center gap-4 text-[11px] font-bold text-ink-500">
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-coral-500" />Грудь</span>
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-mint-500" />Бутылочка</span>
              <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-sun-500" />Прикорм</span>
            </div>
          </Card>
        </motion.div>
      )}

      {/* совет дня */}
      <motion.div {...fadeUp} transition={{ duration: 0.5, delay: 0.24 }} className="mt-4">
        <Card className="flex items-start gap-3.5 bg-[linear-gradient(135deg,#FFF3DE,#FFE9C7)]">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white/80">
            <Sparkles size={19} className="text-sun-500" />
          </span>
          <div>
            <div className="text-[11px] font-black tracking-[0.14em] text-sun-500 uppercase">
              Совет дня
            </div>
            <p className="mt-1 text-[14px] leading-snug font-bold text-ink-900/90">{tip}</p>
          </div>
        </Card>
      </motion.div>

      {/* шторка выбора типа */}
      <Sheet open={sheet === 'pick'} onClose={() => setSheet(null)} title="Новое кормление">
        <div className="flex flex-col gap-3">
          <SheetOption
            kind="breast"
            title="Грудь"
            subtitle="Секундомер и учёт сторон"
            onClick={() => {
              setSheet(null);
              startBreast(last && last.kind === 'breast' && last.leftSec <= last.rightSec ? 'right' : 'left');
              buzz(20);
            }}
          />
          <SheetOption
            kind="bottle"
            title="Бутылочка"
            subtitle="Смесь или сцеженное молоко, объём в мл"
            onClick={() => {
              setSheet(null);
              startBottle();
              buzz(20);
            }}
          />
          <SheetOption
            kind="solid"
            title="Прикорм"
            subtitle="Пюре, каша — быстрая запись в граммах"
            onClick={() => setSheet('solid')}
          />
        </div>
      </Sheet>

      {/* шторка прикорма */}
      <Sheet open={sheet === 'solid'} onClose={() => setSheet(null)} title="Прикорм">
        <div className="py-2">
          <Stepper value={grams} onChange={setGrams} step={10} min={10} max={400} unit="г" />
          <div className="mt-3 flex justify-center gap-2">
            {[30, 60, 80, 100, 150].map((g) => (
              <button
                key={g}
                onClick={() => setGrams(g)}
                className={`rounded-full px-3.5 py-1.5 text-[13px] font-extrabold transition-colors ${
                  grams === g ? 'bg-coral-500 text-white' : 'bg-white text-ink-500'
                }`}
              >
                {g} г
              </button>
            ))}
          </div>
          <div className="mt-5">
            <GradientButton
              onClick={() => {
                addSolid(grams);
                setSheet(null);
                buzz([25, 50, 25]);
              }}
              tone="mint"
            >
              <CalendarHeart size={19} />
              Сохранить: {grams} г прикорма
            </GradientButton>
          </div>
        </div>
      </Sheet>
    </div>
  );
}

function TodayStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white/85 p-3 shadow-card backdrop-blur-xl">
      <div className="flex items-center gap-1 text-[10px] font-black tracking-wider text-ink-500 uppercase">
        {icon}
        <span className="truncate">{label}</span>
      </div>
      <div className="mt-1 text-[15px] font-extrabold">{value}</div>
    </div>
  );
}
