import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Hash, Hourglass, Milk, Timer, MoonStar, TrendingUp } from 'lucide-react';
import { useStore } from '../lib/store';
import { fmtGap, fmtDuration, startOfDay, plural } from '../lib/time';
import { Card, ScreenHeader } from '../components/ui';

const DAY_LETTERS = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];

export function StatsScreen() {
  const feedings = useStore((s) => s.feedings);

  const stats = useMemo(() => {
    const today = startOfDay(Date.now());
    const days: { key: number; label: string; count: number; isToday: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const key = today - i * 86400000;
      const d = new Date(key);
      days.push({
        key,
        label: DAY_LETTERS[d.getDay()],
        count: 0,
        isToday: i === 0,
      });
    }
    const byDay = new Map(days.map((d) => [d.key, d]));
    for (const f of feedings) {
      const k = startOfDay(f.startedAt);
      const slot = byDay.get(k);
      if (slot) slot.count += 1;
    }

    // промежутки за последние 7 дней
    const weekAgo = today - 6 * 86400000;
    const recent = feedings
      .filter((f) => f.startedAt >= weekAgo)
      .sort((a, b) => a.startedAt - b.startedAt);
    const gaps: number[] = [];
    for (let i = 1; i < recent.length; i++) {
      const prevEnd = recent[i - 1].startedAt + recent[i - 1].durationSec * 1000;
      const gap = recent[i].startedAt - prevEnd;
      if (gap > 5 * 60 * 1000 && gap < 24 * 3600 * 1000) gaps.push(gap);
    }
    const avgGap = gaps.length ? gaps.reduce((a, b) => a + b, 0) / gaps.length : null;
    const maxGap = gaps.length ? Math.max(...gaps) : null;

    const breastSec = recent
      .filter((f) => f.kind === 'breast')
      .reduce((a, f) => a + f.durationSec, 0);
    const bottleMl = recent
      .filter((f) => f.kind === 'bottle')
      .reduce((a, f) => a + f.amount, 0);

    return {
      days,
      weekCount: recent.length,
      avgPerDay: recent.length / 7,
      avgGap,
      maxGap,
      breastSec,
      bottleMl,
    };
  }, [feedings]);

  const maxCount = Math.max(1, ...stats.days.map((d) => d.count));

  return (
    <div>
      <ScreenHeader title="Статистика" subtitle="последние 7 дней" />

      {/* график */}
      <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }}>
        <Card>
          <div className="mb-1 flex items-center gap-2">
            <TrendingUp size={15} className="text-coral-500" />
            <span className="text-xs font-black tracking-wider text-ink-500 uppercase">
              Кормлений в день
            </span>
          </div>
          <div className="mt-4 flex h-36 items-end justify-between gap-2">
            {stats.days.map((d, i) => (
              <div key={d.key} className="flex flex-1 flex-col items-center gap-1.5">
                <span
                  className={`text-[11px] font-extrabold tabular-nums ${d.isToday ? 'text-coral-600' : 'text-ink-300'}`}
                >
                  {d.count || ''}
                </span>
                <motion.div
                  initial={{ height: 6 }}
                  animate={{ height: Math.max(6, (d.count / maxCount) * 92) }}
                  transition={{ type: 'spring', damping: 22, stiffness: 200, delay: i * 0.05 }}
                  className={`w-full max-w-9 rounded-full ${
                    d.isToday
                      ? 'bg-[linear-gradient(180deg,#FFA48C,#F25C40)] shadow-pop'
                      : 'bg-[linear-gradient(180deg,#FFD9CD,#FFC7B8)]'
                  }`}
                />
                <span
                  className={`text-[10px] font-black uppercase ${d.isToday ? 'text-coral-600' : 'text-ink-500/70'}`}
                >
                  {d.label}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>

      {/* сводка */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <StatTile
          icon={<Hash size={16} className="text-coral-500" />}
          label="Всего кормлений"
          value={String(stats.weekCount)}
          sub={`≈ ${stats.avgPerDay.toFixed(1)} в день`}
          delay={0.06}
        />
        <StatTile
          icon={<Hourglass size={16} className="text-lilac-500" />}
          label="Средний интервал"
          value={stats.avgGap !== null ? fmtGap(stats.avgGap) : '—'}
          sub="между кормлениями"
          delay={0.1}
        />
        <StatTile
          icon={<Timer size={16} className="text-mint-500" />}
          label="Время у груди"
          value={stats.breastSec ? fmtDuration(stats.breastSec) : '—'}
          sub="за 7 дней"
          delay={0.14}
        />
        <StatTile
          icon={<Milk size={16} className="text-sun-500" />}
          label="Смеси / молока"
          value={stats.bottleMl ? `${stats.bottleMl >= 1000 ? (stats.bottleMl / 1000).toFixed(1) + ' л' : stats.bottleMl + ' мл'}` : '—'}
          sub="за 7 дней"
          delay={0.18}
        />
      </div>

      {stats.maxGap !== null && (
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.24, duration: 0.45 }}>
          <div className="mt-4 flex items-center gap-3.5 rounded-[1.75rem] bg-[linear-gradient(135deg,#4A3440,#33232E)] p-4.5 text-white shadow-soft">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white/12">
              <MoonStar size={20} className="text-lilac-300" />
            </span>
            <div>
              <div className="text-[13px] font-bold text-white/70">Самый долгий перерыв</div>
              <div className="text-[1.05rem] font-extrabold">{fmtGap(stats.maxGap)}</div>
            </div>
            <span className="ml-auto rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-extrabold text-white/60">
              {stats.weekCount} {plural(stats.weekCount, 'запись', 'записи', 'записей')}
            </span>
          </div>
        </motion.div>
      )}

      {stats.weekCount === 0 && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-6 text-center text-sm font-semibold text-ink-500"
        >
          Добавьте несколько кормлений — здесь появятся красивые графики.
        </motion.p>
      )}
    </div>
  );
}

function StatTile({
  icon,
  label,
  value,
  sub,
  delay = 0,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.45 }}
      className="rounded-[1.5rem] bg-white/85 p-4 shadow-card backdrop-blur-xl"
    >
      <div className="flex items-center gap-1.5 text-[10px] font-black tracking-wider text-ink-500 uppercase">
        {icon}
        <span className="truncate">{label}</span>
      </div>
      <div className="font-display mt-2 text-[1.35rem] leading-none font-bold">{value}</div>
      <div className="mt-1 text-xs font-bold text-ink-500">{sub}</div>
    </motion.div>
  );
}
