import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Timer,
  History,
  BarChart3,
  Settings as SettingsIcon,
  BellRing,
} from 'lucide-react';
import { useStore } from './lib/store';
import { Background } from './components/ui';
import { HomeScreen } from './screens/Home';
import { HistoryScreen } from './screens/History';
import { StatsScreen } from './screens/Stats';
import { SettingsScreen } from './screens/Settings';
import { ActiveFeedingOverlay } from './components/ActiveFeeding';
import { playDing, buzz, fireSystemNotification } from './lib/notify';
import { fmtGap } from './lib/time';

type Tab = 'home' | 'history' | 'stats' | 'settings';

interface Toast {
  id: number;
  title: string;
  body: string;
}

const NAV: { tab: Tab; label: string; icon: typeof Timer }[] = [
  { tab: 'home', label: 'Главная', icon: Timer },
  { tab: 'history', label: 'История', icon: History },
  { tab: 'stats', label: 'Статистика', icon: BarChart3 },
  { tab: 'settings', label: 'Настройки', icon: SettingsIcon },
];

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [toast, setToast] = useState<Toast | null>(null);
  const active = useStore((s) => s.active);

  /* ------------------------- напоминания по графику ------------------------ */
  useEffect(() => {
    const push = (title: string, body: string) => {
      const s = useStore.getState();
      setToast({ id: Date.now(), title, body });
      if (s.settings.sound) playDing();
      if (s.settings.vibrate) buzz([60, 80, 60, 80, 60]);
      fireSystemNotification(title, body);
    };

    const check = () => {
      const s = useStore.getState();
      if (!s.settings.notifications || s.active) return;
      const last = s.feedings[0];
      if (!last) return;
      const dueAt = last.startedAt + last.durationSec * 1000 + s.settings.intervalMin * 60000;
      const now = Date.now();
      const name = s.settings.babyName || 'малыша';

      // предупреждение заранее
      if (
        s.settings.remindMin > 0 &&
        now >= dueAt - s.settings.remindMin * 60000 &&
        now < dueAt
      ) {
        const key = `${dueAt}-pre`;
        if (!s.notified[key]) {
          s.markNotified(key);
          push(
            'Скоро кормление',
            `Через ${s.settings.remindMin} мин пора кормить ${name}`,
          );
        }
      }

      // основное + повтор каждые 10 минут, пока не покормили
      if (now >= dueAt) {
        const bucket = Math.floor((now - dueAt) / 600000);
        const key = `${dueAt}-main-${bucket}`;
        if (!s.notified[key]) {
          s.markNotified(key);
          push(
            'Время кормить!',
            bucket === 0
              ? `Прошло ${fmtGap(s.settings.intervalMin * 60000)} с последнего кормления`
              : `Кормление опаздывает на ${fmtGap(now - dueAt)}`,
          );
        }
      }
    };

    const id = setInterval(check, 10000);
    const t = setTimeout(check, 1500);
    return () => {
      clearInterval(id);
      clearTimeout(t);
    };
  }, []);

  // автоскрытие тоста
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 6000);
    return () => clearTimeout(t);
  }, [toast]);

  return (
    <div className="relative min-h-dvh font-sans">
      <Background />

      {/* контент */}
      <main
        className="relative z-10 mx-auto max-w-md px-5 pb-32"
        style={{ paddingTop: 'max(1.25rem, env(safe-area-inset-top))' }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
          >
            {tab === 'home' && <HomeScreen />}
            {tab === 'history' && <HistoryScreen />}
            {tab === 'stats' && <StatsScreen />}
            {tab === 'settings' && <SettingsScreen />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* тост-напоминание */}
      <AnimatePresence>
        {toast && (
          <motion.button
            key={toast.id}
            initial={{ opacity: 0, y: -70, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.96 }}
            transition={{ type: 'spring', damping: 24, stiffness: 320 }}
            onClick={() => setToast(null)}
            className="fixed inset-x-4 top-[max(0.85rem,env(safe-area-inset-top))] z-[70] mx-auto flex max-w-sm items-center gap-3.5 rounded-3xl bg-white/95 p-4 text-left shadow-soft backdrop-blur-xl"
          >
            <span className="flex h-12 w-12 shrink-0 animate-breathe items-center justify-center rounded-2xl bg-[linear-gradient(140deg,#FFB98C,#F25C40)]">
              <BellRing size={22} className="text-white" />
            </span>
            <span>
              <span className="block text-[15px] font-black">{toast.title}</span>
              <span className="block text-[13px] leading-snug font-bold text-ink-500">
                {toast.body}
              </span>
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* нижняя навигация */}
      <nav
        className="fixed inset-x-4 bottom-0 z-40 mx-auto max-w-md"
        style={{ bottom: 'max(1rem, env(safe-area-inset-bottom))' }}
      >
        <div className="flex items-center justify-around rounded-[1.9rem] bg-white/85 px-2 py-2.5 shadow-soft backdrop-blur-xl">
          {NAV.map((item) => {
            const isActive = tab === item.tab;
            const Icon = item.icon;
            return (
              <motion.button
                key={item.tab}
                whileTap={{ scale: 0.9 }}
                onClick={() => {
                  setTab(item.tab);
                  buzz(8);
                }}
                className="relative flex w-16 flex-col items-center gap-0.5 py-1"
              >
                {isActive && (
                  <motion.span
                    layoutId="nav-dot"
                    className="absolute -top-2.5 h-1.5 w-8 rounded-full bg-[linear-gradient(90deg,#FFB98C,#F25C40)]"
                    transition={{ type: 'spring', damping: 26, stiffness: 380 }}
                  />
                )}
                <Icon
                  size={23}
                  strokeWidth={isActive ? 2.5 : 2}
                  className={isActive ? 'text-coral-600' : 'text-ink-300'}
                />
                <span
                  className={`text-[10px] font-extrabold ${
                    isActive ? 'text-coral-600' : 'text-ink-300'
                  }`}
                >
                  {item.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </nav>

      {/* активное кормление поверх всего */}
      <AnimatePresence>{active && <ActiveFeedingOverlay key="active" />}</AnimatePresence>
    </div>
  );
}
