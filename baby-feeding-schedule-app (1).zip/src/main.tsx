import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// PWA: офлайн + установка на домашний экран (только в браузере по http/https)
if (
  "serviceWorker" in navigator &&
  (location.protocol === "https:" || location.protocol === "http:")
) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}
