import { ReactNode, useEffect, useId, useState, type ComponentType } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Minus, Plus, Baby, Milk, Apple } from 'lucide-react';
import { cn } from '../utils/cn';
import type { FeedingKind } from '../lib/store';

/* ---------------------------------- hook ---------------------------------- */

export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

/* -------------------------------- kind meta ------------------------------- */

type IconComponent = ComponentType<{ size?: number | string; className?: string; strokeWidth?: number | string }>;

export const KIND_META: Record<
  FeedingKind,
  { label: string; short: string; icon: IconComponent; tile: string; iconColor: string; soft: string; ring: string }
> = {
  breast: {
    label: 'Грудное вскармливание',
    short: 'Грудь',
    icon: Baby,
    tile: 'bg-coral-100',
    iconColor: 'text-coral-600',
    soft: 'bg-coral-50',
    ring: 'ring-coral-200',
  },
  bottle: {
    label: 'Бутылочка',
    short: 'Смесь / молоко',
    icon: Milk,
    tile: 'bg-mint-100',
    iconColor: 'text-mint-600',
    soft: 'bg-mint-50',
    ring: 'ring-mint-200',
  },
  solid: {
    label: 'Прикорм',
    short: 'Пюре / каша',
    icon: Apple,
    tile: 'bg-sun-100',
    iconColor: 'text-sun-500',
    soft: 'bg-sun-50',
    ring: 'ring-sun-200',
  },
};

/* -------------------------------- backdrop -------------------------------- */

export function Background() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
      <div className="absolute inset-0 bg-[linear-gradient(180deg,#FFF7EF_0%,#FFECE2_38%,#FDF1E8_100%)]" />
      <div className="absolute -top-24 -left-20 h-80 w-80 rounded-full bg-[radial-gradient(circle,#FFC9B5_0%,transparent_70%)] opacity-80 animate-blob-a" />
      <div className="absolute top-1/3 -right-28 h-96 w-96 rounded-full bg-[radial-gradient(circle,#FFE6A8_0%,transparent_70%)] opacity-70 animate-blob-b" />
      <div className="absolute bottom-[-120px] left-1/4 h-96 w-96 rounded-full bg-[radial-gradient(circle,#BFEDE0_0%,transparent_70%)] opacity-60 animate-blob-c" />
    </div>
  );
}

/* ---------------------------------- card ---------------------------------- */

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-[1.75rem] bg-white/85 p-5 shadow-card backdrop-blur-xl', className)}>
      {children}
    </div>
  );
}

/* ------------------------------- screen header ---------------------------- */

export function ScreenHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <div className="mb-5 flex items-end justify-between gap-3">
      <div>
        <h1 className="text-[1.65rem] leading-tight font-black tracking-tight">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm font-semibold text-ink-500">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

/* ------------------------------ progress ring ----------------------------- */

export function Ring({
  size = 250,
  stroke = 13,
  progress,
  overdue = false,
  children,
  className,
}: {
  size?: number;
  stroke?: number;
  progress: number;
  overdue?: boolean;
  children?: ReactNode;
  className?: string;
}) {
  const id = useId();
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(1, progress));
  return (
    <div className={cn('relative', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={`g-${id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={overdue ? '#FF8B70' : '#FFB98C'} />
            <stop offset="55%" stopColor={overdue ? '#F25C40' : '#FF7A5C'} />
            <stop offset="100%" stopColor={overdue ? '#D9432A' : '#F25C40'} />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="#F5E3D9"
          strokeWidth={stroke}
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={`url(#g-${id})`}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          animate={{ strokeDashoffset: c * (1 - p) }}
          transition={{ duration: 0.7, ease: [0.33, 1, 0.68, 1] }}
          style={{ filter: 'drop-shadow(0 4px 10px rgba(242,92,64,0.35))' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

/* ------------------------------ gradient button ---------------------------- */

export function GradientButton({
  children,
  onClick,
  className,
  tone = 'coral',
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  tone?: 'coral' | 'mint';
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      onClick={onClick}
      className={cn(
        'flex h-14 w-full items-center justify-center gap-2.5 rounded-full text-[1.05rem] font-extrabold text-white transition-shadow',
        tone === 'coral'
          ? 'bg-[linear-gradient(135deg,#FF9D6C_0%,#FF7A5C_45%,#F25C40_100%)] shadow-pop'
          : 'bg-[linear-gradient(135deg,#41C79C_0%,#22B184_60%,#15916C_100%)] shadow-[0_10px_30px_-10px_rgba(34,177,132,0.5)]',
        className,
      )}
    >
      {children}
    </motion.button>
  );
}

/* ---------------------------------- chip ---------------------------------- */

export function Chip({
  icon,
  label,
  value,
  tone,
  className,
}: {
  icon?: ReactNode;
  label: string;
  value: string;
  tone?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'flex flex-col gap-1 rounded-2xl p-3.5',
        tone ?? 'bg-cream-100',
        className,
      )}
    >
      <div className="flex items-center gap-1.5 text-[11px] font-bold tracking-wide text-ink-500 uppercase">
        {icon}
        {label}
      </div>
      <div className="text-[15px] leading-tight font-extrabold">{value}</div>
    </div>
  );
}

/* ---------------------------------- sheet --------------------------------- */

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-ink-900/30 backdrop-blur-[3px]"
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 32, stiffness: 350 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            onDragEnd={(_, info) => {
              if (info.offset.y > 110 || info.velocity.y > 600) onClose();
            }}
            className="absolute inset-x-0 bottom-0 mx-auto max-w-md rounded-t-[2rem] bg-cream-50 px-5 pt-3 pb-[max(1.5rem,env(safe-area-inset-bottom))] shadow-soft"
          >
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-ink-300/50" />
            <div className="mb-4 flex items-center justify-between">
              {title ? <h2 className="text-xl font-black tracking-tight">{title}</h2> : <span />}
              <button
                onClick={onClose}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-ink-500 shadow-sm"
                aria-label="Закрыть"
              >
                <X size={18} strokeWidth={2.4} />
              </button>
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

/* ------------------------------ segmented control -------------------------- */

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  activeClass,
  className,
}: {
  options: { value: T; label: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  activeClass?: string;
  className?: string;
}) {
  const lid = useId();
  return (
    <div className={cn('flex rounded-full bg-cream-200/70 p-1.5', className)}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              'relative flex flex-1 items-center justify-center gap-1.5 rounded-full py-2.5 text-sm font-extrabold transition-colors',
              active ? 'text-white' : 'text-ink-500',
            )}
          >
            {active && (
              <motion.span
                layoutId={lid}
                transition={{ type: 'spring', damping: 30, stiffness: 380 }}
                className={cn(
                  'absolute inset-0 rounded-full shadow-sm',
                  activeClass ?? 'bg-[linear-gradient(135deg,#FF9D6C,#F25C40)]',
                )}
              />
            )}
            <span className="relative z-10 flex items-center gap-1.5">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* --------------------------------- stepper -------------------------------- */

export function Stepper({
  value,
  onChange,
  step = 1,
  min = 0,
  max = 999,
  unit,
  className,
}: {
  value: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  unit?: string;
  className?: string;
}) {
  const btn =
    'flex h-11 w-11 items-center justify-center rounded-full bg-white text-ink-900 shadow-sm active:scale-95 transition-transform';
  return (
    <div className={cn('flex items-center justify-center gap-4', className)}>
      <button className={btn} onClick={() => onChange(Math.max(min, value - step))} aria-label="Меньше">
        <Minus size={18} strokeWidth={2.6} />
      </button>
      <div className="min-w-[7.5rem] text-center">
        <span className="font-display text-3xl font-bold">{value}</span>
        {unit && <span className="ml-1.5 text-sm font-bold text-ink-500">{unit}</span>}
      </div>
      <button className={btn} onClick={() => onChange(Math.min(max, value + step))} aria-label="Больше">
        <Plus size={18} strokeWidth={2.6} />
      </button>
    </div>
  );
}

/* ------------------------------- sheet option ------------------------------ */

export function SheetOption({
  kind,
  title,
  subtitle,
  onClick,
}: {
  kind: FeedingKind;
  title: string;
  subtitle: string;
  onClick: () => void;
}) {
  const meta = KIND_META[kind];
  const Icon = meta.icon;
  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-4 rounded-3xl p-4 text-left ring-1 transition-colors',
        meta.soft,
        meta.ring,
      )}
    >
      <span className={cn('flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl', meta.tile)}>
        <Icon size={26} className={meta.iconColor} strokeWidth={2.2} />
      </span>
      <span className="flex-1">
        <span className="block text-[1.05rem] font-extrabold">{title}</span>
        <span className="block text-[13px] font-semibold text-ink-500">{subtitle}</span>
      </span>
    </motion.button>
  );
}
