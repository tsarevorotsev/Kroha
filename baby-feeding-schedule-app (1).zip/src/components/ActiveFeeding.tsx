import { motion } from 'framer-motion';
import { X, Check, ArrowLeftRight, Milk, Baby } from 'lucide-react';
import { useStore } from '../lib/store';
import { fmtStopwatch, fmtDuration } from '../lib/time';
import { useNow } from './ui';
import { buzz } from '../lib/notify';
import { cn } from '../utils/cn';

export function ActiveFeedingOverlay() {
  const active = useStore((s) => s.active);
  const switchSide = useStore((s) => s.switchSide);
  const setBottleMl = useStore((s) => s.setBottleMl);
  const finishActive = useStore((s) => s.finishActive);
  const cancelActive = useStore((s) => s.cancelActive);
  const now = useNow(500);

  if (!active) return null;

  const totalSec = Math.max(0, Math.round((now - active.startedAt) / 1000));

  let leftSec = 0;
  let rightSec = 0;
  if (active.kind === 'breast') {
    const add = Math.round((now - active.sideSwitchedAt) / 1000);
    leftSec = active.leftSec + (active.side === 'left' ? add : 0);
    rightSec = active.rightSec + (active.side === 'right' ? add : 0);
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 60 }}
      transition={{ type: 'spring', damping: 28, stiffness: 260 }}
      className="fixed inset-0 z-[60] overflow-hidden"
    >
      {/* фон */}
      <div className="absolute inset-0 bg-[linear-gradient(170deg,#FF9D6C_0%,#FF7A5C_45%,#E4533A_100%)]" />
      <div className="absolute -top-24 -right-16 h-72 w-72 rounded-full bg-white/10" />
      <div className="absolute top-40 -left-24 h-64 w-64 rounded-full bg-white/10" />
      <div className="absolute -bottom-20 right-10 h-56 w-56 rounded-full bg-white/10" />

      <div className="relative mx-auto flex h-full max-w-md flex-col px-6 pb-8">
        {/* верхняя строка */}
        <div className="flex items-center justify-between pt-4">
          <div className="flex items-center gap-2.5 rounded-full bg-white/15 px-4 py-2 backdrop-blur-sm">
            {active.kind === 'breast' ? (
              <Baby size={18} className="text-white" />
            ) : (
              <Milk size={18} className="text-white" />
            )}
            <span className="text-sm font-extrabold text-white">
              {active.kind === 'breast' ? 'Кормление грудью' : 'Кормление из бутылочки'}
            </span>
          </div>
          <button
            onClick={cancelActive}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/15 text-white backdrop-blur-sm"
            aria-label="Отменить"
          >
            <X size={20} strokeWidth={2.5} />
          </button>
        </div>

        {/* секундомер */}
        <div className="mt-10 text-center text-white">
          <div className="text-[11px] font-bold tracking-[0.22em] uppercase opacity-80">
            Идёт кормление
          </div>
          <motion.div
            key={active.kind}
            initial={{ scale: 0.94, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="font-display mt-2 text-[3.6rem] leading-none font-bold tabular-nums drop-shadow-lg"
          >
            {fmtStopwatch(totalSec)}
          </motion.div>
        </div>

        {/* контент */}
        <div className="mt-9 flex-1">
          {active.kind === 'breast' ? (
            <div>
              {/* переключатель стороны */}
              <div className="flex rounded-[1.6rem] bg-white/15 p-1.5 backdrop-blur-sm">
                {(['left', 'right'] as const).map((side) => {
                  const isActive = active.side === side;
                  return (
                    <motion.button
                      key={side}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        if (!isActive) {
                          switchSide();
                          buzz(20);
                        }
                      }}
                      className={cn(
                        'relative flex-1 rounded-[1.25rem] py-4 text-center transition-colors',
                        isActive ? 'text-coral-600' : 'text-white/85',
                      )}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="side-pill"
                          className="absolute inset-0 rounded-[1.25rem] bg-white shadow-lg"
                          transition={{ type: 'spring', damping: 30, stiffness: 380 }}
                        />
                      )}
                      <span className="relative z-10 block text-base font-extrabold">
                        {side === 'left' ? 'Левая' : 'Правая'}
                      </span>
                      <span className="relative z-10 mt-0.5 block text-xs font-bold opacity-80">
                        {fmtDuration(side === 'left' ? leftSec : rightSec)}
                      </span>
                    </motion.button>
                  );
                })}
              </div>

              <button
                onClick={() => {
                  switchSide();
                  buzz(20);
                }}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-full border-2 border-white/40 py-3 text-sm font-extrabold text-white"
              >
                <ArrowLeftRight size={16} strokeWidth={2.5} />
                Сменить сторону
              </button>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-2xl bg-white/15 p-3.5 backdrop-blur-sm">
                  <div className="text-[10px] font-bold tracking-[0.16em] text-white/75 uppercase">
                    Левая всего
                  </div>
                  <div className="mt-1 font-display text-lg font-bold text-white tabular-nums">
                    {fmtStopwatch(leftSec)}
                  </div>
                </div>
                <div className="rounded-2xl bg-white/15 p-3.5 backdrop-blur-sm">
                  <div className="text-[10px] font-bold tracking-[0.16em] text-white/75 uppercase">
                    Правая всего
                  </div>
                  <div className="mt-1 font-display text-lg font-bold text-white tabular-nums">
                    {fmtStopwatch(rightSec)}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-[1.75rem] bg-white/15 p-5 backdrop-blur-sm">
              <div className="text-center text-[11px] font-bold tracking-[0.2em] text-white/80 uppercase">
                Объём смеси
              </div>
              <div className="mt-2 flex items-center justify-center gap-5">
                <button
                  onClick={() => {
                    setBottleMl(active.amountMl - 10);
                    buzz(10);
                  }}
                  className="flex h-13 w-13 items-center justify-center rounded-full bg-white/20 text-3xl font-bold text-white active:scale-95"
                >
                  −
                </button>
                <div className="min-w-[8.5rem] text-center">
                  <span className="font-display text-5xl font-bold text-white tabular-nums">
                    {active.amountMl}
                  </span>
                  <span className="ml-1.5 text-base font-bold text-white/80">мл</span>
                </div>
                <button
                  onClick={() => {
                    setBottleMl(active.amountMl + 10);
                    buzz(10);
                  }}
                  className="flex h-13 w-13 items-center justify-center rounded-full bg-white/20 text-3xl font-bold text-white active:scale-95"
                >
                  +
                </button>
              </div>
              <div className="mt-4 flex justify-center gap-2">
                {[60, 90, 120, 150, 180].map((ml) => (
                  <button
                    key={ml}
                    onClick={() => {
                      setBottleMl(ml);
                      buzz(10);
                    }}
                    className={cn(
                      'rounded-full px-3.5 py-1.5 text-[13px] font-extrabold transition-colors',
                      active.amountMl === ml
                        ? 'bg-white text-coral-600'
                        : 'bg-white/15 text-white',
                    )}
                  >
                    {ml}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* завершение */}
        <motion.button
          whileTap={{ scale: 0.96 }}
          onClick={() => {
            finishActive();
            buzz([30, 60, 30]);
          }}
          className="flex h-15 w-full items-center justify-center gap-2.5 rounded-full bg-white text-[1.1rem] font-black text-coral-600 shadow-2xl shadow-black/15"
        >
          <Check size={22} strokeWidth={3} />
          Завершить кормление
        </motion.button>
        <button
          onClick={cancelActive}
          className="mt-3 w-full py-2 text-center text-sm font-bold text-white/75"
        >
          Отменить и не сохранять
        </button>
      </div>
    </motion.div>
  );
}
