package com.kroha.feeding;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
